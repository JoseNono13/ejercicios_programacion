﻿using System;

namespace relacion_multidimensionales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("┌──────────────────────────────┐");
            Console.WriteLine("│ Relación de Ejercicios       │");
            Console.WriteLine("│ de Arrays Multidimensiónales │");
            Console.WriteLine("├──────────────────────────────┤");
            Console.WriteLine("│ 1. EscribeArray3x3           │");
            Console.WriteLine("│ 2. Rellena3x3                │");
            Console.WriteLine("│ 3. RellenaAleatorio3x3       │");
            Console.WriteLine("│ 4. SumaArray3x3              │");
            Console.WriteLine("│ 5. EscribeArrayBi            │");
            Console.WriteLine("│ 6. RellenaAleatorioBi        │");
            Console.WriteLine("│ 7. RellenaEnordenBi          │");
            Console.WriteLine("│ 8. SumaArrayBi               │");
            Console.WriteLine("│ 9. Suma2ArraysBi             │");
            Console.WriteLine("│10. CopiaArrayBi              │");
            Console.WriteLine("│11. CopiaArrayBiPro           │");
            Console.WriteLine("│12. RellenaArrayAjedrez       │");
            Console.WriteLine("│13. RellenaDiagonal           │");
            Console.WriteLine("│14. RellenaX                  │");
            Console.WriteLine("│15. RellenaCuadros            │");
            Console.WriteLine("└──────────────────────────────┘");
            Console.Write("Dime un ejercicio: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    {
                        int[,] a = { { 1, 2, 3 },
                                     { 4, 5, 6 },
                                     { 7, 8, 9 } };
                        EscribeArray3x3(a);
                    }
                    break;
                case 2:
                    {
                        int[,] a = new int[3, 3];
                        Rellena3x3(a);
                        EscribeArray3x3(a);
                    }
                    break;
                case 3:
                    {
                        int[,] a = new int[3, 3];
                        RellenaAleatorio3x3(a);
                        EscribeArray3x3(a);
                    }
                    break;
                case 4:
                    {
                        int[,] a = { { 1, 1, 1 },
                                     { 1, 2, 1 },
                                     { 1, 1, 1 } };
                        EscribeArray3x3(a);
                        Console.WriteLine("Resultado: " + SumaArray3x3(a));
                    }
                    break;
                case 5:
                    {
                        int[,] a = { { 1, 2, 3 },
                                     { 4, 5, 6 } };
                        EscribeArrayBi(a);
                    }
                    break;
                case 6:
                    {
                        int[,] a = new int[2, 3];
                        RellenaAleatorioBi(a);
                        EscribeArrayBi(a);
                    }
                    break;
                case 7:
                    {
                        int[,] a = new int[2, 3];
                        RellenaEnordenBi(a);
                        EscribeArrayBi(a);
                    }
                    break;
                case 8:
                    {
                        int[,] a = { { 1, 2, 1 },
                                     { 1, 1, 1 } };
                        EscribeArrayBi(a);
                        Console.WriteLine("Resultado: " + SumaArrayBi(a));
                    }
                    break;
                case 9:
                    {
                        int[,] a = { { 1, 2, 1 },
                                     { 1, 1, 1 } };
                        int[,] b = { { 1, 1, 1 },
                                     { 1, 1, 1 } };
                        int[,] c = new int[a.GetLength(0), a.GetLength(1)];
                        Suma2ArraysBi(a, b, c);
                        EscribeArrayBi(c);
                    }
                    break;
                case 10:
                    {
                        int[,] a = new int[2, 3];
                        int[,] b = new int[a.GetLength(0), a.GetLength(1)];
                        RellenaEnordenBi(a);
                        Console.WriteLine("A");
                        EscribeArrayBi(a);
                        Console.WriteLine(  );
                        Console.WriteLine("B");
                        CopiaArrayBi(a, b);
                        EscribeArrayBi(b);
                    }
                    break;
                case 11:
                    {
                        int[,] a = new int[2, 3];
                        Console.WriteLine("A");
                        RellenaEnordenBi(a);
                        EscribeArrayBi(a);
                        Console.WriteLine();
                        Console.WriteLine("RESULTADO");
                        int[,] result = CopiaArrayBiPro(a);
                        EscribeArrayBi(result);
                    }
                    break;
                case 12:
                    {
                        int[,] a = new int[8, 8];
                        RellenaArrayAjedrez(a);
                        EscribeArrayBi(a);
                    }
                    break;
                case 13:
                    {
                        int[,] a = new int[5, 5];
                        EscribeArrayBi(a);
                        Console.WriteLine();
                        RellenaDiagonal(a);
                        EscribeArrayBi(a);
                    }
                    break;
                case 14:
                    {
                        int[,] a = new int[5, 5];
                        EscribeArrayBi(a);
                        Console.WriteLine();
                        RellenaX(a);
                        EscribeArrayBi(a);
                    }
                    break;
                case 15:
                    {
                        int[,] a = new int[8, 8];
                        EscribeArrayBi(a);
                        Console.WriteLine();
                        RellenaCuadrados(a);
                        EscribeArrayBi(a);
                    }
                    break;
            }
        }

        // 1. Escribe la función EscribeArray3x3 a la que le pasas un array bidimensional de tamaño 
        //    3x3 y te lo imprime por pantalla(que quede bonito).
        static void EscribeArray3x3(int[,] a)
        {
            int i, j;

            for (i = 0; i < 3; i++)
            {
                Console.Write("[ ");
                for (j = 0; j < 2; j++)
                {
                    Console.Write(a[i, j] + ", ");
                }
                Console.WriteLine(a[i, j] + " ]");
            }
        }

        // 2. Escribe la función Rellena3x3 a la que le pasas un array bidimensional de 3x3 y te lo 
        //    rellena con los números del 1 al 9.
        static void Rellena3x3(int[,] a)
        {
            int i, j, cont = 1;

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    a[i, j] = cont;
                    cont++;
                }
            }
        }

        // 3. Escribe la función RellenaAleatorio3x3 a la que le pasas un array bidimensional de 
        //    tamaño 3x3 y te lo rellena con números aleatorios.
        static void RellenaAleatorio3x3(int[,] a)
        {
            int i, j;
            Random r = new Random();

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {

                    a[i, j] = r.Next(1, 10);
                }
            }
        }

        // 4. Escribe la función SumaArray3x3 a la que le pasas un array de 3x3 y te suma todos los 
        //    números.Te devuelve un entero con el resultado.
        static int SumaArray3x3(int[,] a)
        {
            int i, j, result = 0;

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    result = result + a[i, j];
                }
            }

            return result;
        }

        // 5. Escribe la función EscribeArrayBi a la que le pasas un array bidimensional de cualquier 
        //    tamaño y te lo imprime por pantalla.
        static void EscribeArrayBi(int[,] a)
        {
            int i, j;

            for (i = 0; i < a.GetLength(0); i++)
            {
                Console.Write("[ ");
                for (j = 0; j < a.GetLength(1) - 1; j++)
                {
                    Console.Write(a[i, j] + ", ");
                }
                Console.WriteLine(a[i, j] + " ]");
            }
        }

        // 6. Escribe la función RellenaAleatorioBi a la que le pasas un array bidimensional de 
        //    cualquier tamaño y te lo rellena con números aleatorios.
        static void RellenaAleatorioBi(int[,] a)
        {
            int i, j;
            Random r = new Random();

            for (i = 0; i < a.GetLength(0); i++)
            {
                for (j = 0; j < a.GetLength(1); j++)
                {
                    a[i, j] = r.Next(1, 10);
                }
            }
        }


        // 7. Escribe la función RellenaEnordenBi a la que le pasas un array bidimensional de
        //    cualquier tamaño y te lo rellena con los números a partir del 1 en orden.
        static void RellenaEnordenBi(int[,] a)
        {
            int i, j, cont = 1;
            Random r = new Random();

            for (i = 0; i < a.GetLength(0); i++)
            {
                for (j = 0; j < a.GetLength(1); j++)
                {
                    a[i, j] = cont;
                    cont++;
                }
            }
        }


        // 8. Escribe la función SumaArrayBi a la que le pasas un array bidimensional y te suma
        //    todos los números. Te devuelve un entero con el resultado.
        static int SumaArrayBi(int[,] a)
        {
            int i, j, result = 0;

            for (i = 0; i < a.GetLength(0); i++)
            {
                for (j = 0; j < a.GetLength(1); j++)
                {
                    result = result + a[i, j];
                }
            }

            return result;
        }


        // 9. Escribe la función Suma2ArraysBi a la que le pasas 3 arrays del mismo tamaño, los dos
        //    primeros con datos y el tercero vacío.Sumará el contenido de los dos primeros arrays
        //    y pondrá el resultado en el tercero (suma la misma posición del array 1 y el array 2 y
        //    pone el resultado de esa suma en la misma posición del array 3).
        static void Suma2ArraysBi(int[,] a, int[,] b, int[,] c)
        {
            if (a.GetLength(0) == b.GetLength(0) && a.GetLength(1) == b.GetLength(1))
            {
                for (int i = 0;i < a.GetLength(0); i++) 
                {
                    for (int j = 0; j < a.GetLength(1); j++)
                    {
                        c[i, j] = a[i, j] + b[i, j];
                    }
                }
            }
        }

        // 10. Escribe la función CopiaArrayBi a la que le pasas dos arrays, uno con datos y otro
        //     vacío, y te copia el contenido del primero al segundo.
        static void CopiaArrayBi(int[,] a, int[,] b) 
        {
            if (a.GetLength(0) == b.GetLength(0) && a.GetLength(1) == b.GetLength(1))
            {
                for (int i = 0; i < a.GetLength(0); i++)
                {
                    for (int j = 0; j < a.GetLength(1); j++)
                    {
                        b[i, j] = a[i, j];
                    }
                }
            }
        }


        // 11. Escribe la función CopiaArrayBiPro a la que le pasas un array y te devuelve otro del
        //     mismo tamaño y con los mismos datos.
        static int[,] CopiaArrayBiPro(int[,] a)
        {
            int[,] result = new int[a.GetLength(0), a.GetLength(1)];

            CopiaArrayBi(a, result);

            return result;
        }


        // 12. Escribe la función RellenaArrayAjedrez que te rellena un array de 8x8 con la forma de
        //     un tablero de ajedrez, usando el valor 1 para las casillas blancas y 0 para las negras.
        static void RellenaArrayAjedrez(int[,] a) 
        {
            int cont = 0;

            for (int i = 0; i < a.GetLength(0); i++)
            {
                if (i % 2 == 0)
                {
                    cont = 0;
                }
                else
                {
                    cont = 1;
                }

                for (int j = 0; j < a.GetLength(1); j++)
                {
                    a[i, j] = cont;
                    cont = (cont + 1) % 2;
                }
            }
        }

        //13. Escribe la función RellenaDiagonal que te rellena un array cuadrado con el número ‘1’ 
        //en la diagonal principal, el número ‘2’ en el triángulo que queda por encima y el ‘3’ en
        //el triángulo que queda por debajo.
        static void RellenaDiagonal(int[,] a) 
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        a[i, j] = 1;
                    }
                    else
                    {
                        if (i < j)
                        {
                            a[i, j] = 2;
                        }
                        else
                        {
                            a[i,j] = 3;
                        }
                    }
                }
            }
        }


        //14. Escribe la función RellenaX que te rellena un array cuadrado con el número ‘1’ en las
        //dos diagonales y el ‘2’ en el resto.
        static void RellenaX(int[,] a)
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        a[i,j] = 1;
                    }
                    else
                    {
                        if (i + j == a.GetLength(1) - 1)
                        {
                            a[i,j] = 1;
                        }
                        else
                        {
                            a[i,j] = 2;
                        }
                    }
                }
            }
        }

        //15. Escribe la función RellenaCuadros que te rellena un array cuadrado de lado par (o sea,
        //2x2, 4x4, 6x6, etc.) en cuatro cuadros.El cuadro superior izquierdo lo rellena con ‘1’, el
        //superior derecho, con ‘2’, el inferior izquierdo con ‘3’ y el inferior derecho con ‘4’.
        static void RellenaCuadrados(int[,] a)
        {
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a.GetLength(1); j++)
                {
                    if (i < a.GetLength(0) / 2 && j < a.GetLength(1) / 2)
                    {
                        a[i,j] = 1;
                    }
                    else
                    {
                        if (i < a.GetLength(0) / 2 && j >= a.GetLength(1) / 2)
                        {
                            a[i,j] = 2;
                        }
                        else
                        {
                            if (i >= a.GetLength(0) / 2 && j < a.GetLength(1) / 2)
                            {
                                a[i,j] = 3;
                            }
                            else
                            {
                                a[i,j] = 4;
                            }
                        }
                    }
                }
            }
        }
    }
}