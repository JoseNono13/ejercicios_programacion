﻿using System;

namespace relacion_listas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("┌─────────────────────────┬────────────────────────────┐");
            Console.WriteLine("│ Relación de Ejercicios  │ Relación de Ejercicios     │");
            Console.WriteLine("│ de Listas (1)           │ de Listas (2)              │");
            Console.WriteLine("├─────────────────────────┼────────────────────────────┤");
            Console.WriteLine("│ 1. LeeLista             │  9. OrdenaListaPalabras    │");
            Console.WriteLine("│ 2. LeeListaN            │ 10. OrdenaListaPalabras2   │");
            Console.WriteLine("│ 3. EscribeLista         │ 11. InsertaArrayEnArrayPro │");
            Console.WriteLine("│ 4. EliminaNegativos     │ 12. SorteoBonoloto         │");
            Console.WriteLine("│ 5. ClasificaNumeros     │ 13. EliminaRepetidos       │");
            Console.WriteLine("│ 6. EliminaRepetidos     │ 14. UnionListas            │");
            Console.WriteLine("│ 7. OrdenaListaSeleccion │ 15. InterseccionListas     │");
            Console.WriteLine("│ 8. OrdenaListaInsercion │ 16. DesordenaLista         │");
            Console.WriteLine("│                         │ 17. ModaLista              │");
            Console.WriteLine("│                         │ 18. PuntuacionesTrampolin  │");
            Console.WriteLine("└─────────────────────────┴────────────────────────────┘");
            Console.Write("Dime un ejercicio: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1: 
                    {
                        List<int> l = new List<int>();
                        LeeLista(l);
                        EscribeLista(l);
                    } break;
                case 2:
                    {
                        List<int> l = new List<int>();
                        LeeListaN(l, 5);
                        EscribeLista(l);
                    }
                    break;
                case 3:
                    {
                        List<int> l = new List<int>() { 1, 2, 3, 4, 5};
                        EscribeLista(l);
                    }
                    break;
                case 4:
                    {
                        List<int> l = new List<int>() { -1, 2, 3, -4, -5 };
                        EscribeLista(l);
                        EliminaNegativos(l);
                        EscribeLista(l);
                    }
                    break;
                case 5:
                    {
                        List<int> l = new List<int>() { -1, 2, 3, -4, -5 };
                        List<int> l1 = new List<int>();
                        List<int> l2 = new List<int>();
                        EscribeLista(l);
                        ClasificaNumeros(l, l1, l2);
                        EscribeLista(l1);
                        EscribeLista(l2);
                    }
                    break;
                case 6:
                    {
                        List<int> l = new List<int>() { -1, 2, 3, -4, -5, -1, 3 };
                        EscribeLista(l);
                        EliminaRepetidos(l);
                    }
                    break;
                case 7:
                    {
                        List<int> l = new List<int>() { -1, 2, 3, -4, -5, -1, 3 };
                        EscribeLista(l);
                        OrdenaListaSeleccion(l);
                    }
                    break;
                case 8:
                    {
                        List<int> l = new List<int>() { -1, 2, 3, -4, -5, -1, 3 };
                        EscribeLista(l);
                        OrdenaListaInsercion(l);
                    }
                    break;
                case 9:
                    {
                        List<string> l = new List<string>() { "hola", "don", "pepito", "como", "estás" };
                        EscribeListaString(l);
                        OrdenaListaPalabras(l);
                    }
                    break;
                case 10:
                    {
                        List<string> l = new List<string>() { "hola", "don", "pepito", "como", "estás" };
                        EscribeListaString(l);
                        OrdenaListaPalabras2(l);
                    }
                    break;
                case 11: 
                    {
                        int pos;
                        Console.Write("Dime una posición: ");
                        pos = int.Parse(Console.ReadLine());
                        int[] a = { 1, 2, 3 };
                        int[] b = { 4, 5, 6 };
                        InsertaArrayEnArrayPro(a, b, pos);
                        
                    } 
                    break;
                case 12:
                    {
                        EscribeLista(SorteoBonoloto());
                    }
                    break;
                case 13:
                    {
                        int[] a = { 1, 2, 3, 1, 4, 5, 6, 1 };
                        EscribeArray(a);
                        int[] b = EliminaRepetidos(a);
                        EscribeArray(b);
                    }
                    break;
                case 14:
                    {
                        List<int> l1 = new List<int>() { 1, 2, 3 };
                        List<int> l2 = new List<int>() { 3, 4, 5 };
                        List<int>l3 = UnionListas(l1, l2);
                        EscribeLista(l3);
                    }
                    break;
                case 15:
                    {
                        List<int> l1 = new List<int>() { 1, 2, 3 };
                        List<int> l2 = new List<int>() { 3, 4, 5 };
                        List<int> l3 = InterseccionListas(l1, l2);
                        EscribeLista(l3);
                    }
                    break;
                case 16:
                    {
                        List<int> l = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 };
                        EscribeLista(l);
                        EscribeLista(DesordenaLista(l));
                    }
                    break;
                case 17:
                    {
                        List<int> l = new List<int>() { 2, 1, 4, 6, 2, 5, 3, 2, 5 };
                        EscribeLista(l);
                        Console.WriteLine("El elemento más repetido es: " + ModaLista(l));
                    }
                    break;
                case 18:
                    {
                        List<int> l = new List<int>() { 1, 1, 2, 6, 9, 4, 3};
                        EscribeLista(l);
                        Console.WriteLine("Puntuación: " + PuntuacionesTrampolin(l));
                    }
                    break;
            }
        }

        // 1. Escribe la función LeeLista que va leyendo enteros desde el teclado y los va metiendo
        //    en una lista.La función ira leyendo valores hasta que escribamos un -1. La lista la
        //    pasamos por parámetro.
        static void LeeLista(List<int> l) 
        {
            int v = 0;

            Console.Write("Inserta valor en la lista: ");
            v = int.Parse(Console.ReadLine());
            if (v != -1)
            {
                l.Add(v);
            }

            while (v != -1)
            {
                Console.Write("Inserta valor en la lista: ");
                v = int.Parse(Console.ReadLine());

                if (v != -1)
                {
                    l.Add(v);
                }
            }
        }

        // 2. Escribe la función LeeListaN que lee desde el teclado el número de enteros que le 
        //    digamos.Para ello, le pasaremos dos parámetros: la lista y un entero.
        static void LeeListaN(List<int> l, int n) 
        {
            for (int i = 0; i < n; i++)
            {
                Console.Write("Inserta valor en la lista: ");
                int v = int.Parse(Console.ReadLine());
                l.Add(v);
            }
        }

        // 3. Escribe la función EscribeLista a la que le pasas una lista y te escribe su contenido por 
        //    pantalla.Para diferenciarla de los arrays, usaremos angulos para delimitarla.
        static void EscribeLista(List<int> l)
        {
            Console.Write("< ");
            for (int i = 0; i < l.Count; i++)
            {
                Console.Write(l[i] + " ");
            }
            Console.WriteLine(">");
        }

        // 4. Escribe la función EliminaNegativos que elimine todos los números negativos de una 
        //    lista de enteros.
        static void EliminaNegativos(List<int> l) 
        {
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i] < 0)
                {
                    l.RemoveAt(i);
                    i--;
                }
            }
        }

        // 5. Escribe la función ClasificaNumeros a la que le pasamos tres listas. La primera contiene 
        //    un montón de números positivos y negativos.Habrá que copiar los positivos en la
        //    primera lista y los negativos en la segunda lista, y después ordenar las dos listas.
        static void ClasificaNumeros(List<int> l, List<int> l1, List<int> l2) 
        {
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i] >= 0)
                {
                    l1.Add(l[i]);
                }
                else
                {
                    l2.Add(l[i]);
                }
            }

            l1.Sort();
            l2.Sort();
        }

        // 6. Escribe la función EliminaRepetidos a la que le pasas una lista y te elimina los elementos 
        //    repetidos, dejando sólo uno de cada(ej.: <1,2,3,1> = <1,2,3>). La forma más fácil es ir
        //    copiando de una lista a otra sólo los elementos que no estén ya introducidos(p.ej., usando Contains).
        static void EliminaRepetidos(List<int> l) 
        {
            List<int> list = new List<int>();

            for (int i = 0; i < l.Count; i++)
            {
                if (!list.Contains(l[i]))
                {
                    list.Add(l[i]);
                }
            }

            l.Clear();
            l.AddRange(list);   
            EscribeLista(l);
        }

        // 7. Escribe la función OrdenaListaSeleccion a la que le pasas una lista de enteros 
        //    desordenada y te la ordena mediante el algoritmo de selección.
        //    La ordenación por selección funciona de la siguiente forma:
        //    - Buscamos el elemento más pequeño de nuestra lista.
        //    - Lo metemos en otra lista resultado.
        //    - Lo eliminamos de nuestra lista.
        //    - Repetimos hasta que nuestra lista se quede vacía y todos los elementos hayan
        //      pasado a la lista resultado en orden.
        static void OrdenaListaSeleccion(List<int> l)
        {
            List<int> result = new List<int>();
            int min;

            while (l.Count > 0)
            {
                min = l.Min();
                result.Add(min);
                l.Remove(l.Min());
            }

            l.Clear();
            l.AddRange(result);
            EscribeLista(l);
        }

        // 8. Escribe la función OrdenaListaInsercion a la que le pasas una lista de enteros 
        //    desordenada y te la ordena mediante el algoritmo de inserción.
        //    La ordenación por inserción funciona de la siguiente forma:
        //    - Cogemos cada elemento en orden de nuestra lista.
        //    - A la hora de meterlo en la lista resultado lo metemos de manera que la lista
        //      resultado se quede ordenada. Para ello, vamos pasando por la lista resultado hasta
        //      que encontremos un valor mayor e insertamos nuestro número delante.
        //    - Repetimos hasta que nuestra lista se quede vacía y todos los elementos hayan
        //      pasado a la lista resultado en orden.
        static void OrdenaListaInsercion(List<int> l) 
        {
            List<int> result = new List<int>();
            int i, j;
            bool insertado;

            for (i = 0; i < l.Count; i++)
            {
                insertado = false;
                for (j = 0; j < result.Count; j++)
                {
                    if (l[i] < result[j])
                    {
                        result.Insert(j, l[i]); 
                        j = result.Count;
                        insertado = true;
                    }
                }
                if (!insertado)
                {
                    result.Add(l[i]);
                }
            }

            l.Clear();
            l.AddRange(result);
            EscribeLista(l);
        }

        // 9. Escribe la función OrdenaListaPalabras a la que le pasas una lista de cadenas que 
        //    contiene palabras y te las ordena alfabéticamente.
        static void OrdenaListaPalabras(List<string> l) 
        {
            List<string> result = new List<string>();
            string s;

            while (l.Count > 0) 
            {
                s = MinimoCadena(l);
                result.Add(s);
                l.Remove(s);
            }

            l.Clear();
            l.AddRange(result);
            EscribeListaString(l);
        }

        static string MinimoCadena(List<string> l) 
        {
            string min = l[0];

            for (int i = 0; i < l.Count; i++)
            {
                if (min.CompareTo(l[i]) > 0)
                {
                    min = l[i];
                }
            }

            return min;
        }

        static void EscribeListaString(List<string> l)
        {
            Console.Write("< ");
            for (int i = 0; i < l.Count; i++)
            {
                Console.Write(l[i] + " ");
            }
            Console.WriteLine(">");
        }

        // 10. Escribe la función OrdenaListaPalabras2 a la que le pasas una lista de cadenas que 
        //     contiene palabras y te las ordena por tamaño(la más pequeña el principio).
        static void OrdenaListaPalabras2(List<string> l) 
        {
            List<string> result = new List<string>();
            string s;

            while (l.Count > 0)
            {
                s = MinimoCadenaTamaño(l);
                result.Add(s);
                l.Remove(s);
            }

            l.Clear();
            l.AddRange(result);
            EscribeListaString(l);
        }

        static string MinimoCadenaTamaño(List<string> l)
        {
            string min = l[0];

            for (int i = 0; i < l.Count; i++)
            {
                if (min.Length > l[i].Length)
                {
                    min = l[i];
                }
            }

            return min;
        }

        // 11. Escribe la función InsertaArrayEnArrayPro a la que le pasamos tres parámetros: un 
        //     array de enteros, una posición en ese array y otro array de enteros.La función insertará
        //     en el primer array, a partir de la posición indicada, todo el contenido del segundo array,
        //     y nos devolverá otro array con el resultado. Para ello, usaremos una lista como paso
        //     intermedio: copiamos el array a la lista, realizamos la inserción en la lista y luego
        //     convertiremos la lista en un array y lo devolveremos.
        static void InsertaArrayEnArrayPro(int[] a, int[] b, int pos) 
        {
            List<int> l = new List<int>(a);
            l.InsertRange(pos, b);
            l.ToArray();
            EscribeLista(l);
        }

        // 12. Escribe la función SorteoBonoloto que nos da los 6 números que van a tocar en el 
        //    próximo sorteo.Para ello, meteremos en una lista los 49 números, elegiremos una
        //    posición al azar, guardaremos el número en otra lista y lo eliminaremos de la primera
        //    (para que no pueda volver a salir). Al terminar de sortear los 6 números, devolveremos
        //    una lista que contenga el resultado.
        static List<int> SorteoBonoloto()
        {
            Random r = new Random();

            int pos;
            List<int> l = new List<int>();
            List<int> l2 = new List<int>();
            RellenaLista49(l);
            for (int i = 0; i < 6; i++)
            {
                pos = r.Next(l.Count);
                l2.Add(l[pos]);
                l.Remove(l[pos]);
            }

            return l2;
        }
        static List<int> RellenaLista49(List<int> l)
        {
            for (int i = 1; i <= 49; i++)
            {
                l.Add(i);
            }

            return l;
        }

        // 13. Escribe la función EliminaRepetidos a la que le pasamos un array (en el que puede que 
        //     aparezcan elementos repetidos) y nos devuelve otro array en el que no hay repetidos.
        //     Podemos usar listas para que sea más sencillo.
        static int[] EliminaRepetidos(int[] a)
        {
            List<int> l = new List<int>(a);
            int i, j;
            for (i = 0; i < l.Count; i++)
            {
                for (j = i + 1; j < l.Count; j++)
                {
                    if (l[i] == l[j])
                    {
                        l.RemoveAt(j);
                        j--;
                    }
                }
            }

            return l.ToArray();
        }
        static void EscribeArray(int[] a)
        {
            Console.Write("[");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i]);

                if (i != a.Length - 1)
                {
                    Console.Write(", ");
                }
            }
            Console.WriteLine("]");
        }

        // 14. Escribe la función UnionListas a la que le pasas dos listas (que representan conjuntos) y 
        //     que te devuelve otra lista que representará la unión de ambos conjuntos.Esto es, los
        //     elementos que estén o en la primera lista o en la segunda (si están en las dos, sólo hay
        //     que meterlos una vez).
        static List<int> UnionListas(List<int> l1, List<int> l2)
        {
            List<int> l = new List<int>(l1);
            for (int i = 0; i < l2.Count; i++)
            {
                if (!l1.Contains(l2[i]))
                {
                    l.Add(l2[i]);
                }
            }

            return l;
        }

        // 15. Escribe la función InterseccionListas a la que le pasas dos listas(que representan
        //     conjuntos) y que te devuelve otra lista que representará la intersección de ambos
        //     conjuntos.Esto es, los elementos que estén tanto en la primera lista como en la segunda.
        static List<int> InterseccionListas(List<int> l1, List<int> l2)
        {
            List<int> l = new List<int>();
            for (int i = 0; i < l2.Count; i++)
            {
                if (l1.Contains(l2[i]))
                {
                    l.Add(l2[i]);
                }
            }

            return l;
        }

        // 16. Escribe la función DesordenaLista a la que le pasas una lista y te la desordena.Para ello,
        //     iremos cogiendo al azar elementos de la lista y poniéndolos en otra lista (quitándolos de
        //     la primera). La segunda lista, contendrá los elementos al azar.
        static List<int> DesordenaLista(List<int> l1)
        {
            Random r = new Random();
            List<int> l2 = new List<int>();
            int pos;

            while (l1.Count > 0)
            {
                pos = r.Next(l1.Count);
                l2.Add(l1[pos]);
                l1.RemoveAt(pos);
            }

            return l2;
        }

        // 17. Escribe la función ModaLista que nos devuelva la moda(el valor que más veces se
        //     repite) de una lista de enteros.
        static int ModaLista(List<int> l1)
        {
            int max = VecesRepite(l1, l1[0]);
            int valor = l1[0];

            for (int i = 0; i < l1.Count; i++)
            {
                if (VecesRepite(l1, l1[i]) > max)
                {
                    max = VecesRepite(l1, l1[i]);
                    valor = l1[i];

                }
            }

            return valor;
        }

        static int VecesRepite(List<int> l1, int num)
        {
            int numerorepetidos = 0;
            for (int i = 0; i < l1.Count; i++)
            {
                if (num == l1[i])
                {
                    numerorepetidos++;
                }
            }

            return numerorepetidos;
        }

        // 18. Escribe la función PuntuacionesTrampolin.La función recibirá una lista con siete
        //     números reales que se corresponderán a las notas obtenidas por un saltador de
        //     trampolín de 3 metros.En este deporte, para calcular la nota final, se eliminan las dos
        //     notas más altas y las dos más bajas, sumándose las tres que quedan.Por tanto, nuestra
        //     función eliminará los dos valores más altos y los dos más bajos del la lista y, además,
        //     devolverá un real que será la suma de los tres valores que quedan.
        static int PuntuacionesTrampolin(List<int> l1)
        {
            int suma = 0;

            for (int i = 0; i < 2; i++)
            {
                l1.Remove(MinimoLista(l1));
            }

            for (int i = 0; i < 2; i++)
            {
                l1.Remove(MaximoLista(l1));
            }

            for (int i = 0; i < l1.Count; i++)
            {
                suma = suma + l1[i];
            }

            return suma;
        }

        static int MinimoLista(List<int> l)
        {
            int minimo = l[0];

            for (int i = 1; i < l.Count; i++)
            {
                if (minimo > l[i])
                {
                    minimo = l[i];
                }

            }

            return minimo;
        }

        static int MaximoLista(List<int> l)
        {
            int max = l[0];

            for (int i = 1; i < l.Count; i++)
            {
                if (max < l[i])
                {
                    max = l[i];
                }
            }

            return max;
        }
    }
}