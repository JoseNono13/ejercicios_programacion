﻿using System;

namespace relacion_arrays
{
    class Program
    {
        // 1. Escribe una función “EscribeArray5” a la que le pasamos un array de tipo entero de 
        //    cinco elementos y lo escribe por pantalla de la siguiente forma: [23, 43, 1, -3, 6]
        static void EscribeArray5(int[] a) 
        {
            Console.Write("[");
            for (int i = 0; i < 5; i++)
            {
                Console.Write(a[i]);

                if (i != a.Length - 1)
                {
                    Console.Write(", ");
                }
            }
            Console.WriteLine("]");
        }

        // 2. Escribe una función “EscribeArray” a la que le pasamos un array de enteros del tamaño
        //    que sea y lo escribe por pantalla de la misma forma.Tendremos que usar la propiedad 
        //    “Length” para saber el tamaño del array desde dentro de la función.
        static void EscribeArray(int[] a) 
        {
            Console.Write("[");
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i]);

                if (i != a.Length - 1)
                {
                    Console.Write(", ");
                }
            }
            Console.WriteLine("]");
        }

        // 3. Escribe una función “LeeArray5” que lea un array de enteros de 5 elementos. Habrá 
        //    que pasarle el array ya definido y él lo rellenará pidiéndole los valores al usuario por
        //    consola.
        static void LeeArray5(int[] a) 
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Dime el entero que quieres rellenar en la posición " + i);
                int pos = int.Parse(Console.ReadLine());
                a[i] = pos;
            }
        }

        // 4. Escribe una función “LeeArray” que lea un array de enteros de cualquier tamaño. El 
        //    array lo crearemos fuera de la función y dentro de la función usaremos la propiedad 
        //    “Length” para saber cuál es el tamaño y cuántos datos debemos leer.
        static void LeeArray(int[] a)
        {
            for (int i = 0; i <= a.Length - 1; i++)
            {
                Console.WriteLine("Dime el entero que quieres rellenar en la posición " + i);
                int pos = int.Parse(Console.ReadLine());
                a[i] = pos;
            }

        }

        // 5. Escribe una función “PonCeros5” que modifique el contenido de un array de enteros 
        //    de cinco elementos y ponga en todas las posiciones un 0.
        static void PonCeros5(int[] a)
        {
            for (int i = 0; i < 5; i++)
            {
                a[i] = 0;
            }
        }

        // 6. Escribe una función “PonCero” que haga lo mismo para un array de enteros de 
        //    cualquier tamaño.
        static void PonCero(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = 0;
            }
        }

        // 7. Escribe una función “SumaArray5” que sume todas las posiciones de un array de 
        //    enteros de cinco elementos y nos devuelva el resultado.
        static int SumaArray5(int[] a)
        {
            int suma = 0;
            for (int i = 0; i < 5; i++)
            {
                suma = suma + a[i];
            }

            return suma;
        }

        // 8. Escriba una función “SumaArray” que haga lo mismo para un array de enteros de 
        //    cualquier tamaño.
        static int SumaArray(int[] a)
        {
            int suma = 0;
            for (int i = 0; i < a.Length; i++)
            {
                suma = suma + a[i];
            }

            return suma;
        }

        // 9. Escribe una función “MediaArray5” que nos calcule el valor medio de los elementos de 
        //    un array de enteros de tamaño 5.
        static double MediaArray5(int[] a)
        {
            int suma = 0;
            double media = 0;
            for (int i = 0; i < 5; i++)
            {
                suma = suma + a[i];
            }
            media = suma / 5;

            return media;
        }

        // 10. Escribe una función “MediaArray” que haga lo mismo para un array de enteros de 
        //     cualquier tamaño.
        static double MediaArray(int[] a)
        {
            int suma = 0;
            double media = 0;
            for (int i = 0; i < a.Length; i++)
            {
                suma = suma + a[i];
            }
            media = suma / a.Length;

            return media;
        }

        // 11. Escribe una función “RellenaEnOrden” que nos rellena un array de enteros con los
        //     números desde el 1 en adelante(1, 2, 3, 4... hasta el tamaño del array).
        static void RellenaEnOrden(int[] a) 
        {
            for (int i = 0; i < a.Length;  i++)
            {
                a[i] = i + 1;
            }
        }

        // 12. Escribe una función “RellenaEnOrdenDesc” que nos rellena un array con los valores 
        //     siguientes: tamaño del array, tamaño del array-1, etc., 3, 2, 1.
        static void RellenaEnOrdenDesc(int[] a)
        {
            int cont = 0;
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = a.Length - cont;
                cont++;
            }
        }

        // 13. Escribe una función “RellenaAleatorio” a la que le pasamos un array de enteros y nos 
        //     lo rellena de valores aleatorios entre 1 y 10.
        static void RellenaAleatorio(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                Random r = new Random();
                int aleatorio = r.Next(1, 10 + 1);
                a[i] = aleatorio;
            }
        }

        // 14. Escribe una función “EstaOrdenado” a la que le pasas un array de enteros y te 
        //     devuelve un booleano que será verdadero si los elementos del array se encuentran en
        //     orden ascendente.
        static bool EstaOrdenado(int[] a) 
        {
            int cont = 0;
            for (int i = 0; i < a.Length - 1; i++)
            {
                if (a[i] <= a[i + 1])
                {
                    cont++;
                }
            }

            if (cont == a.Length - 1)
            {
                return true;
            }
            else
            {
                return false;
            }

            // for (int i = 0; i < a.Length - 1; i++)
            // {
            //     if (a[i] <= a[i + 1])
            //     {
            //         return false;
            //     }
            // }
            // return true;
        }

        // 15. Escribe una función “NumeroImpares” a la que le pasas un array de enteros y te 
        //     devuelve un entero que corresponde a la cantidad de números impares que tenemos
        //     en el array.
        static int NumerosImpares(int[] a) 
        {
            int n = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 != 0)
                {
                    n++;
                }
            }

            return n;
        }

        // 16. Escribe una función “MinArray” a la que le pasas un array y te devuelve el valor más 
        //     pequeño de los contenidos en dicho array.
        static int MinArray(int[] a) 
        {
            int min = a[0];
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] < min)
                {
                    min = a[i];
                }
            }

            return min;
        }

        // 17. Escribe una función “MaxArray” que te devuelve el más grande.
        static int MaxArray(int[] a)
        {
            int max = a[0];
            for (int i = 0; i < a.Length; i++)
            {
                if (max < a[i])
                {
                    max = a[i];
                }
            }

            return max;
        }

        // 18. Escribe una función “NumeroAprobados” a la que se le pasa un array de enteros y, 
        // suponiendo que son notas, nos devuelve el número de aprobados(valores entre 5 y 10).
        static int NumeroAprobados(int[] a)
        {
            int aprobados = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] >= 5 && a[i] <= 10)
                {
                    aprobados++;
                }
            }

            return aprobados;
        }

        // 19. Escribe una función “PorEncimaDe” a la que le pasamos un valor “limite” y nos 
        //     devuelve cuántos elementos del array son iguales o mayores que ese límite.Por
        //     ejemplo, le pasamos el valor 10 y nos dice cuántos elementos son 10 o más.
        static int PorEncimaDe(int[] a) 
        {
            int cont = 0;

            Console.Write("Dime el límite: ");
            int limite = int.Parse(Console.ReadLine());

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] >= limite)
                {
                    cont++;
                }
            }

            return cont;
        }

        // 20. Escribe una función “CuantosCeros” a la que le pasamos un array y nos devuelve un 
        //     entero que nos dice cuántos elementos tienen el valor 0. 
        static int CuantosCeros(int[] a) 
        {
            int cont = 0;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == 0)
                {
                    cont++;
                }
            }

            return cont;
        }

        // 21. Escribe una función “CopiaArray” a la que le pasas dos arrays por parámetro (array1 y 
        //     array2, por ejemplo) del mismo tamaño(se debería comprobar dentro de la función). 
        //     La función copiara el contenido del primer array al segundo array.
        static void CopiaArray(int[] a, int[] b) 
        {
            if (a.Length == b.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    b[i] = a[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 22. Escribe una función “CopiaArrayInvertido” a la que le pasas dos arrays por parámetro y 
        //     te copia el contenido del primer array al segundo array pero en orden inverso(Ej.: si el
        //     primero es [5,6,7,8,9], en el segundo se copiará[9, 8, 7, 6, 5]).
        static void CopiaArrayInvertido(int[] a, int[] b)
        {
            int cont = a.Length - 1;

            if (a.Length == b.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    b[cont] = a[i];
                    cont--;
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 23. Escribe una función “SumaArrays” a la que le pasamos tres arrays. Los dos primeros 
        //     contendrán los datos que hay que sumar y en el tercero guardaremos el resultado(Ej.: 
        //     [1, 2, 3] + [8, 6, 8] = [9, 8, 11]).
        static void SumaArrays(int[] a, int[] b, int[] c) 
        {
            if (a.Length == b.Length && b.Length == c.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                   c[i] = a[i] + b[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 24. Escribe también las funciones “RestaArrays”, “MultiplicaArrays” y “DivideArrays”.
        static void RestaArrays(int[] a, int[] b, int[] c)
        {
            if (a.Length == b.Length && b.Length == c.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    c[i] = a[i] - b[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        static void MultiplicaArrays(int[] a, int[] b, int[] c)
        {
            if (a.Length == b.Length && b.Length == c.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    c[i] = a[i] * b[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        static void DivideArrays(int[] a, int[] b, int[] c)
        {
            if (a.Length == b.Length && b.Length == c.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    c[i] = a[i] / b[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 25. Escribe una función “InvierteArray” a la que le pasamos un array de enteros y modifica
        //     su contenido invirtiendo la posición de sus elementos(Ej.: [1,2,3] -> [3,2,1]).
        static void InvierteArray(int[] a) 
        {
            int j = a.Length - 1, temp = 0;
            for (int i = 0; i < j; i++)
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
                j--;
            }
        }

        // 26. Escribe una función “ComparaArrays” a la que le pasamos dos arrays y nos devuelve 
        //     un boolean que será verdadero si los dos arrays tienen el mismo tamaño y contienen
        //     los mismos datos.
        static bool ComparaArrays(int[] a, int[] b) 
        {
            bool result = true;

            if (a.Length == b.Length)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (a[i] != b[i])
                    {
                        result = false;
                        i = a.Length;
                    }
                }
            }
            else
            {
                return false;
            }

            return result;
        }

        // DUDA: toString
        // 27. Escribe una función “PonNotasArray” a la que le pasamos dos arrays del mismo 
        //     tamaño.El primero será un array de reales(double) y contendrá las notas de los
        //     alumnos.El segundo será un array de booleanos en el que deberemos escribir en cada
        //     posición “true” si la nota es mayor o igual que 5 (aprobado) y “false” en caso contrario.
        static void PonNotasArray(double[] notas, bool[] aprobados) 
        {
            if (notas.Length == aprobados.Length)
            {
                for (int i = 0; i < notas.Length; i++)
                {
                    if (notas[i] >= 5)
                    {
                        aprobados[i] = true;
                        //Console.WriteLine(aprobados[i]);
                    }
                    else
                    {
                        aprobados[i] = false;
                        //Console.WriteLine(aprobados[i]);
                    }
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 28. Escribe una función “ConcatenaArrays55” a la que le pasamos tres arrays de enteros.
        //     Los dos primeros tendrán un tamaño de 5 y contendrán los datos que hay que copiar.
        //     El tercero tendrá un tamaño de 10 y en él copiaremos los datos del primer array y
        //     después los datos del segundo (Ej.: [4,5,6,7,8] & [1,1,2,2,3] = [4, 5, 6, 7, 8, 1, 1, 2, 2, 3]).
        static void ConcatenaArrays55(int[] a, int[] b, int[] c) 
        {
            if (a.Length == 5 && b.Length == 5 && c.Length == 10)
            {
                for (int i = 0; i < a.Length; i++)
                {
                    c[i] = a[i];
                    c[i + 5] = b[i];
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // DUDA: 1 solo for
        // 29. Escribe una función “ConcatenaArrays” a la que pasamos tres arrays con la condición 
        //     de que el tamaño del tercero sea igual a la suma del tamaño de los dos primeros.Hará
        //     lo mismo que la función anterior.
        static void ConcatenaArrays(int[] a, int[] b, int[] c)
        {
            int i, j = 0;

            if (a.Length + b.Length == c.Length)
            {
                for (i = 0; i < a.Length; i++)
                {
                    c[i] = a[i];
                    j++;
                }
                for (i = 0; i < b.Length; i++)
                {
                    c[j] = b[i];
                    j++;
                }
            }
            else
            {
                Console.WriteLine("Los arrays no son del mismo tamaño");
            }
        }

        // 30. Escribe una función “Contiene” a la que le pasamos un array y un valor entero. La 
        //     función nos devolverá “true” si el array contiene el número y “false” si no lo contiene
        static bool Contiene(int[] a, int n) 
        {
            bool result = false;

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == n)
                {
                    result = true;
                }
            }

            return result;
        }

        // 31. Escribe una función “ConcatenaArraysPro” a la que le pasas dos arrays de enteros y te 
        //     devuelve un array cuyo tamaño es la suma del tamaño de ambos y que contiene todos
        //     los elementos del primero y a continuación los del segundo.Esta función devolverá un
        //     array de enteros (int[]) el cuál se creará dentro de la propia función. 
        //     Ej.de uso: int[] a = { 1,2,3};
        //                int[] b = { 4, 5, 6, 7, 2 };
        //                int[] c;
        //                c = ConcatenaArraysPro(a, b);
        static int[] ConcatenaArraysPro(int[] a, int[] b)
        {
            int[] c = new int[a.Length + b.Length];
            ConcatenaArrays(a, b, c);
            return c;
        }

        // 32. Escribe una función “CopiaArrayPro” a la que le pasas un array y te devuelve un array 
        //     del mismo tamaño y con los mismos datos.
        //     Ej.de uso: int[] a = { 1,2,3};
        //                int[] b;
        //                b = CopiaArrayPro(a);
        static int[] CopiaArrayPro(int[] a)
        {
            int[] b = new int[a.Length];
            CopiaArray(a, b);
            return b;
        }

        // 33. Escribe una función “InsertaEnArray” a la que le pasas tres parámetros: un array de 
        //     enteros, un valor entero y una posición. La función insertará el valor en la posición
        //     indicada, desplazando el resto de valores para hacerle hueco. Ej.: Si tenemos el array
        //     [1,2,3,4,5] y queremos insertar el valor “26” en la posición “2”, el resultado será: 
        //     [1,2,26,3,4,5]. Nota: el array habrá que pasarlo por referencia; esto es necesario
        //     siempre que hay que modificar el tamaño de un array.
        static int[] InsertaEnArray(int[] a, int val, int pos) 
        {
            int i;
            int[] b = new int[a.Length + 1];

            for (i = 0; i < pos; i++)
            {
                b[i] = a[i];
                //EscribeArray(b);
            }

            b[pos] = val;
            //EscribeArray(b);

            for (i = pos; i < a.Length; i++)
            {
                b[i + 1] = a[i];
                //EscribeArray(b);
            }

            return b;
        }

        // 34. Escribe una función “BorraDeArray” a la que le pasas dos parámetros: un array de 
        //     enteros y una posición.La función eliminará el elemento colocado en la posición
        //     indicada.Ej.: Si tenemos el array [5,7,2,8,1] y queremos eliminar la posición 1, el
        //     resultado será: [5,2,8,1]. Nota: el array habrá que pasarlo por referencia; esto es
        //     necesario siempre que hay que modificar el tamaño de un array.
        static int[] BorraDeArray(int[] a, int pos)
        {
            int i;
            int[] b = new int[a.Length - 1];

            for (i = 0; i < pos; i++)
            {
                b[i] = a[i];
                //EscribeArray(b);
            }

            for (i = pos + 1; i < a.Length; i++)
            {
                b[i - 1] = a[i];
                //EscribeArray(b);
            }

            return b;
        }

        // 35. Escribe una función “Elimina1ElementoArray” a la que le pasas dos parámetros: un 
        //     array de enteros y un valor entero.La función eliminará del array el valor entero
        //     independientemente de la posición en la que se encuentre.Si el valor se repite, se
        //     eliminará sólo la primera vez que aparece el valor.Nota: el array habrá que pasarlo
        //     por referencia; esto es necesario siempre que hay que modificar el tamaño de un array.
        static int[] Elimina1ElementoArray(int[] a, int val) 
        {
            int[] b = new int[a.Length - 1];

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == val)
                {
                    b = BorraDeArray(a, i);
                    i = a.Length; //Si no pongo esto, se eliminará sólo la ultima vez que aparece el valor.
                }
            }

            return b;
        }

        // 36. Escribe una función “EliminaElementosArray” a la que le pasas dos parámetros: un 
        //     array de enteros y un valor entero.La función eliminará del array el valor entero
        //     independientemente de la posición en la que se encuentre.Si el valor se repite, se
        //     eliminarán todas las veces que se repite.Nota: el array habrá que pasarlo por
        //     referencia; esto es necesario siempre que hay que modificar el tamaño de un array.
        static int[] EliminaElementosArray(int[] a, int val) 
        {
            int[] b = new int[a.Length];

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == val)
                {
                    b = BorraDeArray(a, i);
                    i = a.Length; //Si no pongo esto, se eliminará sólo la ultima vez que aparece el valor.
                }
            }

            return b;
        }





        static void Main(string[] args)
        {
            Console.WriteLine("┌────────────────────────┬────────────────────────┬─────────────────────────┬───────────────────────────┐");
            Console.WriteLine("│ Relación de Ejercicios │ Relación de Ejercicios │ Relación de Ejercicios  │ Relación de Ejercicios    │");
            Console.WriteLine("│ de Arrays (1)          │ de Arrays (2)          │ de Arrays (3)           │ de Arrays (4)             │");
            Console.WriteLine("├────────────────────────┼────────────────────────┼─────────────────────────┼───────────────────────────┼");
            Console.WriteLine("│ 1. escribeArray5       │ 11. rellenaEnOrden     │ 21. copiaArray          │ 31. concatenaArraysPro    │");
            Console.WriteLine("│ 2. escribeArray        │ 12. rellenaEnOrdenDesc │ 22. copiaArrayInvertido │ 32. copiaArrayPro         │");
            Console.WriteLine("│ 3. leeArray5           │ 13. rellenaAleatorio   │ 23. sumaArrays          │ 33. insertaEnArray        │");
            Console.WriteLine("│ 4. leeArray            │ 14. estaOrdenado       │ 24. restaArrays         │ 34. borraDeArray          │");
            Console.WriteLine("│ 5. ponCeros5           │ 15. numeroImpares      │ 25. invierteArray       │ 35. elimina1ElementoArray │");
            Console.WriteLine("│ 6. ponCeros            │ 16. minArray           │ 26. comparaArrays       │ 36. eliminaElementosArray │");
            Console.WriteLine("│ 7. sumaArray5          │ 17. maxArray           │ 27. ponNotasArray       │ 37. insertaArrayEnArray   │");
            Console.WriteLine("│ 8. sumaArray           │ 18. numeroAprobados    │ 28. concatenaArray55    │ 38. subArray              │");
            Console.WriteLine("│ 9. mediaArray5         │ 19. porEncimaDe        │ 29. concatenaArrays     │ 39. recortaArray          │");
            Console.WriteLine("│10. mediaArray          │ 20. cuantosCeros       │ 30. contiene            │ 40. ordenaBurbuja         │");
            Console.WriteLine("└────────────────────────┴────────────────────────┴─────────────────────────┴───────────────────────────┘");

            Console.Write("Dime un ejercicio: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray5(a);
                    }
                    break;
                case 2:
                    {
                        int[] a = { 23, 43, 1 };
                        EscribeArray(a);
                    }
                    break;
                case 3:
                    {
                        int[] a = new int[5];
                        LeeArray5(a);
                        EscribeArray5(a);
                    }
                    break;
                case 4:
                    {
                        Console.Write("Dime el tamaño del array: ");
                        int size = int.Parse(Console.ReadLine());
                        int[] a = new int[size];
                        LeeArray(a);
                        EscribeArray(a);
                    }
                    break;
                case 5:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray5(a);
                        PonCeros5(a);
                        EscribeArray5(a);
                    }
                    break;
                case 6:
                    {
                        int[] a = { 23, 43, 1 };
                        EscribeArray(a);
                        PonCero(a);
                        EscribeArray(a);
                    }
                    break;
                case 7:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray5(a);
                        Console.WriteLine(SumaArray5(a));
                    }
                    break;
                case 8:
                    {
                        int[] a = { 23, 43, 1 };
                        EscribeArray(a);
                        Console.WriteLine(SumaArray(a));
                    }
                    break;
                case 9:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray5(a);
                        Console.WriteLine(MediaArray5(a));
                    }
                    break;
                case 10:
                    {
                        int[] a = { 23, 43, 1 };
                        EscribeArray(a);
                        Console.WriteLine(MediaArray(a));
                    }
                    break;
                case 11:
                    {
                        Console.Write("Dime el tamaño del array: ");
                        int size = int.Parse(Console.ReadLine());
                        int[] a = new int[size];
                        RellenaEnOrden(a);
                        EscribeArray(a);
                    }
                    break;
                case 12:
                    {
                        Console.Write("Dime el tamaño del array: ");
                        int size = int.Parse(Console.ReadLine());
                        int[] a = new int[size];
                        RellenaEnOrdenDesc(a);
                        EscribeArray(a);
                    }
                    break;
                case 13:
                    {
                        Console.Write("Dime el tamaño del array: ");
                        int size = int.Parse(Console.ReadLine());
                        int[] a = new int[size];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                    }
                    break;
                case 14:
                    {

                        int[] a = new int[5];
                        int[] b = { 1, 2, 3, 4, 5};
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(EstaOrdenado(a));
                        EscribeArray(b);
                        Console.WriteLine(EstaOrdenado(b));
                    }
                    break;
                case 15:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(NumerosImpares(a));
                    }
                    break;
                case 16:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(MinArray(a));
                    }
                    break;
                case 17:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(MaxArray(a));
                    }
                    break;
                case 18:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(NumeroAprobados(a));
                    }
                    break;
                case 19:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        EscribeArray(a);
                        Console.WriteLine(PorEncimaDe(a));
                    }
                    break;
                case 20:
                    {
                        int[] a = { 1, 5, 2, 0, 4};
                        EscribeArray(a);
                        Console.WriteLine(CuantosCeros(a));
                    }
                    break;
                case 21:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        int[] b = new int[5];
                        EscribeArray(a);
                        EscribeArray(b);
                        CopiaArray(a, b);
                        EscribeArray(b);
                    }
                    break;
                case 22:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        int[] b = new int[5];
                        EscribeArray(a);
                        EscribeArray(b);
                        CopiaArrayInvertido(a, b);
                        EscribeArray(b);
                    }
                    break;
                case 23:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        int[] b = new int[5];
                        RellenaAleatorio(b);
                        int[] c = new int[5];
                        EscribeArray(a);
                        EscribeArray(b);
                        SumaArrays(a, b, c);
                        EscribeArray(c);
                    }
                    break;
                case 24:
                    {
                        int[] a = new int[5];
                        RellenaAleatorio(a);
                        int[] b = new int[5];
                        RellenaAleatorio(b);
                        int[] c = new int[5];
                        EscribeArray(a);
                        EscribeArray(b);
                        Console.Write("Resta: ");
                        RestaArrays(a, b, c);
                        EscribeArray(c);
                        Console.Write("Multiplicación: ");
                        MultiplicaArrays(a, b, c);
                        EscribeArray(c);
                        Console.Write("División: ");
                        DivideArrays(a, b, c);
                        EscribeArray(c);
                    }
                    break;
                case 25:
                    {
                        int[] a = new int[5];
                        RellenaEnOrden(a);
                        EscribeArray(a);
                        InvierteArray(a);
                        EscribeArray(a);
                    }
                    break;
                case 26:
                    {
                        int[] a = new int[5];
                        int[] b = new int[5];
                        RellenaEnOrden(a);
                        RellenaEnOrden(b);
                        EscribeArray(a);
                        EscribeArray(b);
                        Console.WriteLine(ComparaArrays(a, b));
                        Console.WriteLine();
                        int[] c = new int[5];
                        RellenaEnOrden(a);
                        RellenaAleatorio(c);
                        EscribeArray(a);
                        EscribeArray(c);
                        Console.WriteLine(ComparaArrays(a, c));
                    }
                    break;
                case 27:
                    {
                        double[] notas = { 5.0, 2.75, 9.95, 4.5, 7.5};
                        bool[] aprobados = new bool[5];
                        PonNotasArray(notas, aprobados);
                        foreach (bool res in aprobados)
                        {
                            Console.WriteLine(res);
                        }
                    }
                    break;
                case 28:
                    {
                        int[] a = { 4, 5, 6, 7, 8 };
                        int[] b = { 1, 1, 2, 2, 3 };
                        int[] c = new int[10];
                        EscribeArray(a);
                        EscribeArray(b);
                        ConcatenaArrays55(a, b, c);
                        EscribeArray(c);
                    }
                    break;
                case 29:
                    {
                        int[] a = { 4, 5, 6, 7 };
                        int[] b = { 1, 1, 2, 2, 3 };
                        int[] c = new int[9];
                        EscribeArray(a);
                        EscribeArray(b);
                        ConcatenaArrays(a, b, c);
                        EscribeArray(c);
                    }
                    break;
                case 30:
                    {
                        int[] a = { 4, 5, 6, 7, 8 };
                        Console.Write("Dime un número: ");
                        int n = int.Parse(Console.ReadLine());
                        EscribeArray(a);
                        Console.WriteLine(Contiene(a, n));
                    }
                    break;
                case 31:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        int[] b = { 1, 2, 3 };
                        EscribeArray(a);
                        EscribeArray(b);
                        int[] c = ConcatenaArraysPro(a, b);
                        EscribeArray(c);
                    }
                    break;
                case 32:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        int[] b = CopiaArrayPro(a);
                        EscribeArray(a);
                        EscribeArray(b);
                    }
                    break;
                case 33:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray(a);
                        Console.Write("Dime el valor que quieres insertar: ");
                        int valor = int.Parse(Console.ReadLine());
                        Console.Write("Dime en que posición lo quieres insertar: ");
                        int pos = int.Parse(Console.ReadLine());
                        a = InsertaEnArray(a, valor, pos);
                        EscribeArray(a);
                    }
                    break;
                case 34:
                    {
                        int[] a = { 23, 43, 1, -3, 6 };
                        EscribeArray(a);
                        Console.Write("Dime en que posición lo quieres borrar: ");
                        int pos = int.Parse(Console.ReadLine());
                        a = BorraDeArray(a, pos);
                        EscribeArray(a);
                    }
                    break;
                case 35:
                    {
                        int[] a = { 23, 43, 1, -3, 6, 1 };
                        EscribeArray(a);
                        Console.Write("Dime el valor que quieres borrar: ");
                        int val = int.Parse(Console.ReadLine());
                        a = Elimina1ElementoArray(a, val);
                        EscribeArray(a);
                    }
                    break;
            }
        }
    }
}
