﻿using System;

namespace Ejercicio_4_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 4. Leer tres números por teclado, X, Y y Z, y decidir si están ordenados de menor a mayor.

            int x, y, z;

            Console.WriteLine("Dime el primer numero");
            x = int.Parse(Console.ReadLine());

            Console.WriteLine("Dime el segundo numero");
            y = int.Parse(Console.ReadLine());

            Console.WriteLine("Dime el tercer numero");
            z = int.Parse(Console.ReadLine());

            if (x < y)
            {
                if (y < z)
                {
                    Console.WriteLine("Estan ordenados");
                }
                else 
                {
                    Console.WriteLine("No estan ordenados");
                }
            }

        }
    }
}
