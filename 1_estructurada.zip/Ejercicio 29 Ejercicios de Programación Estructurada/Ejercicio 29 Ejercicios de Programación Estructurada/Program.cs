﻿using System;

namespace Ejercicio_29_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 29. Escribir todos los números impares entre dos números A y B introducidos por teclado. 
            //     Antes habrá que comprobar cuál de los dos números A y B es mayor.

            int a, b;

            Console.WriteLine("Dime un numero");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime otro numero");
            b = int.Parse(Console.ReadLine());

            if (a < b)
            {
                for (int i = a; i <= b; i++)
                {
                    if (i % 2 != 0)
                    {
                        Console.WriteLine(i);
                    }
                }
            }
            else
            {
                if (a > b)
                {
                    for (int i = a; i >= b; i--)
                    {
                        if (i % 2 != 0)
                        {
                            Console.WriteLine(i);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Los número son iguales");
                }
            }
        }
    }
}
