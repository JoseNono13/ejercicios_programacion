﻿using System;

namespace Ejercicio_2_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 2. Determinar si un año es bisiesto o no (los años bisiestos son múltiplos de 4; utilícese el 
            //    operador módulo).

            int anno;

            Console.WriteLine("Dime un año");
            anno = int.Parse(Console.ReadLine());


            if (anno % 4 == 0)
            {
                Console.WriteLine("Es bisiesto");
            }
            else 
            {
                Console.WriteLine("No es bisiesto");
            }

        }
    }
}
