﻿using System;

namespace Ejercicio_36_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 36.Escribe un programa que nos escriba los 10 primeros números que no sean múltiplos ni
            //    de 2 ni de 3.

            for (int i = 0; i <= 30; i++)
            {
                if (i % 2 != 0 && i % 3 != 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
