﻿using System;

namespace Ejercicio_28_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 28. Escribe un programa que te pide dos números. Si el primero es menor que el segundo, 
            //     escribe todos los números comprendidos entre ambos en orden ascendente. Si el
            //     primero es mayor que el segundo, escribe todos los números comprendidos entre
            //     ambos en orden descendente.

            int a, b;

            Console.WriteLine("Dime un número");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime otro número");
            b = int.Parse(Console.ReadLine());

            if (a < b)
            {
                for (int i = a; i <= b; i++)
                {
                    Console.WriteLine(i);
                }
            }
            else
            {
                if (a > b)
                {
                    for (int i = a; i >= b; i--)
                    {
                        Console.WriteLine(i);
                    }
                }
                else
                {
                    Console.WriteLine("Los número son iguales");
                }
            }
        }
    }
}
