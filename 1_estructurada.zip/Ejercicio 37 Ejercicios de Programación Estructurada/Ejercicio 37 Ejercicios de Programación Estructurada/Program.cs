﻿using System;

namespace Ejercicio_37_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 37. Escribe un programa que nos presente un menú con 3 opciones. Eligiendo la opción “a” 
            //     nos escribirá todos los múltiplos de 11 comprendidos entre 1 y 100.Eligiendo la opción 
            //     “b” lo mismo, pero con los múltiplos de 17.Eligiendo la opción “c” lo mismo, pero con
            //     los múltiplos de 23.

            int option;
            
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("1- Los múltiplos de 11 comprendidos entre 1 y 100");
            Console.WriteLine("2- Los múltiplos de 17 comprendidos entre 1 y 100");
            Console.WriteLine("2- Los múltiplos de 23 comprendidos entre 1 y 100");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.Write("Elige una opción: ");
            option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1: 
                    {
                        int i = 0;
                        while (i++ <= 100)
                        {
                            if (i % 11 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                    } 
                    break;

                case 2:
                    {
                        int i = 0;
                        while (i++ <= 100)
                        {
                            if (i % 17 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                    }
                    break;

                case 3:
                    {
                        int i = 0;
                        while (i++ <= 100)
                        {
                            if (i % 23 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                    }
                    break;
            }
        }
    }
}
