﻿using System;

namespace Ejercicio_10_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 10. Escribe un programa que nos escriba los números impares comprendidos entre 1 y 10.

            int n = 1;

            while (n <= 10)
            {
                if (n % 2 != 0)
                {
                    Console.WriteLine(n);
                }
                n++;
            }
        }
    }
}
