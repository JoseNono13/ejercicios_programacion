﻿using System;

namespace Ejercicio_42_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 42. Juego del número secreto. El ordenador elegirá un número al azar entre 1 y 100. El 
            //     usuario irá introduciendo números por teclado, y el ordenador le irá dando pistas: "mi 
            //     número es mayor" o "mi número es menor", hasta que el usuario acierte. Entonces el 
            //     ordenador le felicitará y le comunicará el número de intentos que necesitó para acertar
            //     el número secreto.

            Random r = new Random();
            int secret = r.Next(1, 100 + 1);

            int n , i = 0;

            Console.Write("Dime un número: ");
            n = int.Parse(Console.ReadLine());

            while (n != secret)
            {
                if (n > secret)
                {
                    Console.WriteLine("Es menor");

                }
                else
                {
                    Console.WriteLine("Es mayor");

                }
                i++;

                Console.Write("Dime un número: ");
                n = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Has acertado, necesitaste " + i + " intentos");
        }
    }
}
