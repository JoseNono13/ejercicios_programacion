﻿using System;

namespace Ejercicio_31_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 31. El usuario de este programa será un profesor, que introducirá las notas de sus 30 
            //     alumnos de una en una.El algoritmo debe decirle cuántos suspensos y cuántos
            //     aprobados hay.

            int nota, suspensos = 0, aprobados = 0;

            for (int i = 1; i <= 30; i++)
            {
                Console.WriteLine("Dime una nota:");
                nota = int.Parse(Console.ReadLine());

                if (nota >= 0 && nota < 5)
                {
                    suspensos++;
                }
                else
                {
                    if (nota >= 5 && nota <= 10)
                    {
                        aprobados++;
                    }
                }
            }

            Console.WriteLine("Aprobados: " + aprobados);
            Console.WriteLine("Supensos: " + suspensos);
        }
    }
}
