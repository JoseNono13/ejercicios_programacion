﻿using System;

namespace Ejercicio_23_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 23. Escribe un programa que nos escriba los números del 10 al 20.
            for (int i = 10; i <= 20; i++)
            {
                Console.WriteLine(i);
            }
        }
    }
}
