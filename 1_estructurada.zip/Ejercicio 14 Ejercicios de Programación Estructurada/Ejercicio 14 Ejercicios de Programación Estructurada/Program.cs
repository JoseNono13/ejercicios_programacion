﻿using System;

namespace Ejercicio_14_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 14. Escribe un programa que te pida dos números con la condición de que el segundo sea
            //     mayor que el primero, en caso contrario te pregunta de nuevo el número hasta que sea
            //     correcto.Si los números son correctos, escribe todos los números comprendidos entre
            //     el primer y el segundo número(ambos inclusive).

            int n1, n2, n;

            Console.WriteLine("Dime un numero:");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime otro numero mayor que el primero:");
            n2 = int.Parse(Console.ReadLine());

            n = n1;

            if (n2 < n1)
            {
                while (n2 < n1)
                {
                    Console.WriteLine("El segundo numero debe ser mayor que el primero:");
                    n2 = int.Parse(Console.ReadLine());
                }

                Console.WriteLine("");

                while (n <= n2)
                {
                    Console.WriteLine(n);
                    n++;
                }
            }
            else
            {
                Console.WriteLine("");

                while (n <= n2)
                {
                    Console.WriteLine(n);
                    n++;
                }
            }
        }
    }
}
