﻿using System;

namespace Ejercicio_21_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 21. Calcular en el mismo bucle el valor máximo, el valor mínimo y la media aritmética de
            //     una serie de 10 números introducidos por teclado.

            int n, i = 0;
            double suma = 0, media, max, min, aux = 0;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            max = n;
            min = n;

            while (i < 9)
            {
                Console.WriteLine("Dime un número:");
                n = int.Parse(Console.ReadLine());

                suma = suma + n;

                if (n > max)
                {
                    max = n;
                }
                else
                {
                    if (n < min)
                    {
                        min = n;
                    }
                }

                i++;
            }

            media = suma / 10;

            Console.WriteLine("La media es:" + media);
            Console.WriteLine("El valor máximo es: " + max);
            Console.WriteLine("El valor mínimo es: " + min);
        }
    }
}
