﻿using System;

namespace Ejercicio_17_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            //17. Calcular la suma de todos los números pares entre 1 y 1000. Es decir, 2 + 4 + 6 + ... + 998 
            //    +1000.

            int suma = 0, n = 1;

            while (n <= 1000)
            {
                if (n % 2 == 0)
                {
                    suma = suma + n;
                }
                n++;
            }

            Console.WriteLine(suma);
        }
    }
}
