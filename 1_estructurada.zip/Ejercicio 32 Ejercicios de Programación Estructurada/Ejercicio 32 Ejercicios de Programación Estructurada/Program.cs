﻿using System;

namespace Ejercicio_32_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 32. Calcular el valor máximo de una serie de 10 números introducidos por teclado.

            int n, max = 0;

            Console.WriteLine("Dime un numero:");
            n = int.Parse(Console.ReadLine());
            n = max;

            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine("Dime un numero:");
                n = int.Parse(Console.ReadLine());

                if (n > max)
                {
                    max = n;
                }
            }

            Console.WriteLine("El valor maximo es: " + max);
        }
    }
}
