﻿using System;

namespace Ejercicio_38_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 38. Escribe un programa que calcule el máximo común divisor de 2 números.

            int n1, n2, mcd;

            Console.Write("Dime un número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Dime otro número: ");
            n2 = int.Parse(Console.ReadLine());

            while (n2 != 0)
            {
                mcd = n2;
                n2 = n1 % n2;
                n1 = mcd;
            }

            Console.WriteLine("El MCD es " + n1);
        }
    }
}
