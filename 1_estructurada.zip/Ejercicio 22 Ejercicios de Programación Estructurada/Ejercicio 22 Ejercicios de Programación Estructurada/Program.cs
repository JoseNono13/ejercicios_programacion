﻿using System;

namespace Ejercicio_22_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 22. Calcular el factorial de un número entero N. Recuerda que el factorial de un número es 
            //     el producto de ese número por todos los enteros menores que él. Por ejemplo, el
            //     factorial de 5(simbolizado 5!) se calcula como: 5! = 5 x 4 x 3 x 2 x 1

            int n, fact;

            Console.WriteLine("Dime un número");
            n = int.Parse(Console.ReadLine());

            fact = 1;

            while (n != 0)
            {
                fact = fact * n;;
                n--;
            }

            Console.WriteLine(fact);
        }
    }
}
