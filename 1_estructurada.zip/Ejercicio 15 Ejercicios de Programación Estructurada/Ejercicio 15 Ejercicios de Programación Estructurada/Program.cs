﻿using System;

namespace Ejercicio_15_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 15. Escribe un programa que te pide dos números. Si el primero es menor que el segundo, 
            //     escribe todos los números comprendidos entre ambos en orden ascendente. Si el
            //     primero es mayor que el segundo, escribe todos los números comprendidos entre
            //     ambos en orden descendente.

            int n1, n2, n;

            Console.WriteLine("Dime un numero:");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime otro numero:");
            n2 = int.Parse(Console.ReadLine());

            if (n1 < n2)
            {
                Console.WriteLine("");

                while (n1 <= n2)
                {
                    Console.WriteLine(n1);
                    n1++;
                }
            }
            else
            {
                if (n2 < n1)
                {
                    Console.WriteLine("");

                    while (n2 <= n1)
                    {
                        Console.WriteLine(n1);
                        n1--;
                    }
                }
                else
                {
                    Console.WriteLine("Los numeros son iguales");
                }
            }
        }
    }
}