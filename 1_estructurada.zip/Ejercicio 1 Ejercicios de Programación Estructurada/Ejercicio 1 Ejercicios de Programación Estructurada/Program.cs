﻿using System;

namespace Ejercicio_1_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {

            // 1. Leídos dos números por teclado, A y B, calcular la resta del mayor menos el menor. Por 
            //    ejemplo, si A = 8 y B = 3, el resultado debe ser A – B, es decir, 5.Pero si A = 4 y B = 7, el
            //    resultado debe ser B – A, es decir, 3.

            int a, b, resta;

            Console.WriteLine("Dime un número");
            a = int.Parse(Console.ReadLine());

            Console.WriteLine("Dime otro número");
            b = int.Parse(Console.ReadLine());

            if (a < b)
            {
                resta = b - a;
            }
            else 
            {
                resta = a - b;
            }

            Console.WriteLine("El resultado es " + resta);
        }
    }
}
