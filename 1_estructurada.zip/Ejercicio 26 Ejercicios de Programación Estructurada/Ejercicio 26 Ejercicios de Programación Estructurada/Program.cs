﻿using System;

namespace Ejercicio_26_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 26. Escribe un programa que te pregunte si quieres números pares o impares. Si te dice 
            //     pares, escribe los números pares del 1 al 10 y si te dice impares, escribe los números
            //     impares del 1 al 10.

            int opcion;

            Console.WriteLine("Si quieres números impares pulsa 1");
            Console.WriteLine("Si quieres números pares pulsa 2");
            opcion = int.Parse(Console.ReadLine());

            if (opcion == 1)
            {
                Console.WriteLine("IMPARES");
                for (int i = 1; i <= 10; i++)
                {
                    if (i % 2 != 0)
                    {
                        Console.WriteLine(i);
                    }
                }
            }
            else
            {
                if (opcion == 2)
                {
                    Console.WriteLine("PARES");
                    for (int i = 1; i <= 10; i++)
                    {
                        if (i % 2 == 0)
                        {
                            Console.WriteLine(i);
                        }
                    }
                }
                else
                {

                }
            }
        }
    }
}
