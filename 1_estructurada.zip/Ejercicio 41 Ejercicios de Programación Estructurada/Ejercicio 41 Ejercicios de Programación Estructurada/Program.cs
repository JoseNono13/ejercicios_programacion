﻿using System;

namespace Ejercicio_41_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 41. Generalizar el algoritmo anterior para averiguar todos los números primos que existen 
            //     entre 2 y 1000.

            int i, primos = 0;

            for (int n = 2; n <= 1000; n++)
            {
               primos = 0;

                for (i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                    {
                        primos++;
                    }
                }
                if (primos == 2)
                {
                    Console.WriteLine(n);
                }
            }

            
        }
    }
}
