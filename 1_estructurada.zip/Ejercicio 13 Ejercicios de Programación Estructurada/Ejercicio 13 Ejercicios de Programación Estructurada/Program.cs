﻿using System;

namespace Ejercicio_13_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 13. Escribe un programa que te escribe la tabla de multiplicar del número que le introduzcas
            //     por teclado.

            int n, multiplo = 0, result;

            Console.WriteLine("Dime un numero:");
            n = int.Parse(Console.ReadLine());

            while (multiplo <= 10)
            {
                result = n * multiplo;
                Console.WriteLine(n + " x " + multiplo + " = " + result);
                multiplo++;
            }
        }
    }
}
