﻿using System;

namespace Ejercicio_8_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 8. Dados tres números enteros, A, B, C, determinar cuál es el mayor, cuál el menor y cuál 
            //    el mediano.
            int a, b, c;

            Console.WriteLine("Dime el número a:");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime el número b:");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime el número c:");
            c = int.Parse(Console.ReadLine());

            if (a < b && b < c)
            {
                Console.WriteLine(a + " < " + b + " < " + c);
            }
            else
            {
                if (a < c && c < b)
                {
                    Console.WriteLine(a + " < " + c + " < " + b);
                }
                else
                {
                    if (b < a && a < c)
                    {
                        Console.WriteLine(b + " < " + a + " < " + c);
                    }
                    else
                    {
                        if (b < c && c < a)
                        {
                            Console.WriteLine(b + " < " + c + " < " + a);
                        }
                        else
                        {
                            if (c < a && a < b)
                            {
                                Console.WriteLine(c + " < " + a + " < " + b);
                            }
                            else
                            {
                                if (c < b && b < a)
                                {
                                    Console.WriteLine(c + " < " + b + " < " + a);
                                }
                                else
                                {
                                    Console.WriteLine("Los números no pueden ser iguales");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}