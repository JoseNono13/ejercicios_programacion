﻿using System;

namespace Ejercicio_9_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 9. Escribe un programa que nos escriba los números del 10 al 20

            int n = 10;

            while (n <= 20)
            {
                Console.WriteLine(n);
                n++;
            }
        }
    }
}
