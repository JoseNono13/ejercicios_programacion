﻿using System;

namespace Ejercicio_30_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 30. Calcular la suma de todos los números pares entre 1 y 1000. Es decir, 2 + 4 + 6 + ... + 998 
            //     +1000.

            int n = 0, resultado = 0;

            for (int i = 1; i <= 1000; i++)
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine(i);
                }

                resultado = resultado + i;
            }

            Console.WriteLine("El resultado es: " + resultado);
        }
    }
}
