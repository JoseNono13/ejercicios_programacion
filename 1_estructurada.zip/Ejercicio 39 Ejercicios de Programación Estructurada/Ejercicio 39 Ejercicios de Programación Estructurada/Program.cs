﻿using System;

namespace Ejercicio_39_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 39. Escribe un programa que calcule el mínimo común múltiplo de 2 números.

            int n1, n2, mcd, mcm;
            int a, b;


            Console.Write("Dime un número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Dime otro número: ");
            n2 = int.Parse(Console.ReadLine());

            a = n1;
            b = n2;

            while (b != 0)
            {
                mcd = b;
                b = a % b;
                a = mcd;
            }

            mcm = (n1 / a) * n2;

            Console.WriteLine("El MCM es " + mcm);
        }
    }
}
