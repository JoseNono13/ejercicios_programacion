﻿using System;

namespace Ejercicio_19_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 19. El usuario de este programa será un profesor, que introducirá las notas de sus 30
            //     alumnos de una en una.El algoritmo debe decirle cuántos suspensos y cuántos
            //     aprobados hay.

            int aprobados = 0, suspensos = 0, alumnos = 0;

            double nota;

            Console.WriteLine("Dime una nota:");
            nota = double.Parse(Console.ReadLine());

            while (alumnos < 30)
            {

                alumnos++;

                if (nota >= 0 && nota < 5)
                {
                    suspensos++;
                }
                else
                {
                    if (nota >= 5 && nota <= 10)
                    {
                        aprobados++;
                    }
                }

                Console.WriteLine("Dime otra nota:");
                nota = double.Parse(Console.ReadLine());

            }

            Console.WriteLine("Aprobados: " + aprobados);
            Console.WriteLine("Suspensos: " + suspensos);
        }
    }
}
