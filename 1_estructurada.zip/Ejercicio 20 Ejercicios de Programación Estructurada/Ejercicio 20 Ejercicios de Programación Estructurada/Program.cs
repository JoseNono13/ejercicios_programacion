﻿using System;

namespace Ejercicio_20_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 20. Calcular el valor máximo de una serie de 10 números introducidos por teclado.

            int n, max = 0, i = 1;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            while (i < 10)
            {
                i++;

                if (n > max)
                {
                    max = n;
                }

                Console.WriteLine("Dime otro número:");
                n = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("El valor máximo es: " + max);
        }
    }
}
