﻿using System;

namespace Ejercicio_16_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 16. Escribir todos los números impares entre dos números A y B introducidos por teclado. 
            //     Antes habrá que comprobar cuál de los dos números A y B es mayor.
            int a, b, aux;
            Console.WriteLine("Dime un número:");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime ótro número:");
            b = int.Parse(Console.ReadLine());

            if (a > b)
            {
                aux = a;
                a = b;
                b = aux;
            }

            int n = a;

            while (n <= b)
            {
                if (n % 2 != 0)
                {
                    Console.WriteLine(n);
                }

                n++;
            }
        }
    }
}
