﻿using System;

namespace Ejercicio_6_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 6.Determinar el número de cifras de un número entero. El algoritmo debe funcionar para
            //   números de hasta 5 cifras, considerando los negativos.Por ejemplo, si se introduce el
            //   número 5342, la respuesta del programa debe ser 4.Si se introduce -250, la respuesta
            //   debe ser 3.

            int n, positivo;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            if (n < 0)
            {
                positivo = n * -1;
            }
            else
            {
                positivo = n;
            }

            if (positivo < 10)
            {
                Console.WriteLine("El número es de una cifra");
            }
            else
            {
                if (positivo < 100)
                {
                    Console.WriteLine("El número es de dos cifras");
                }
                else
                {
                    if (positivo < 1000)
                    {
                        Console.WriteLine("El número es de tres cifras");
                    }
                    else
                    {
                        if (positivo < 10000)
                        {
                            Console.WriteLine("El número es de cuatro cifras");
                        }
                        else
                        {
                            if (positivo < 100000)
                            {
                                Console.WriteLine("El número es de cinco cifras");
                            }
                            else
                            {
                                Console.WriteLine("El número es de más de cinco cifras");
                            }
                        }
                    }
                }
            }
        }
    }
}
