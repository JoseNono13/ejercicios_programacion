﻿using System;

namespace Ejercicio_18_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 18. Calcular el valor medio de una serie de valores enteros positivos introducidos por
            //     teclado.Para terminar de introducir valores, el usuario debe teclear un número
            //     negativo.

            int i = 0;
            double n, suma = 0, resultado;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            while (n >= 0)
            {
                suma = suma + n;

                i++;

                Console.WriteLine("Dime otro número:");
                n = int.Parse(Console.ReadLine());

            }

            resultado = suma / i;

            Console.WriteLine(resultado);

        }
    }
}
