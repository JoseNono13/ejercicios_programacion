﻿using System;

namespace Ejercicio_33_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 33. Calcular en el mismo bucle el valor máximo, el valor mínimo y la media aritmética de 
            //     una serie de 10 números introducidos por teclado.

            int n;
            double suma = 0, media, max, min;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            max = n;
            min = n;

            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine("Dime otros número:");
                n = int.Parse(Console.ReadLine());

                suma = suma + n;

                if (n > max)
                {
                    max = n;
                }
                else
                {
                    if (n < min)
                    {
                        min = n;
                    }
                }
            }
            
            media = suma / 10;

            Console.WriteLine("La media es:" + media);
            Console.WriteLine("El valor máximo es: " + max);
            Console.WriteLine("El valor mínimo es: " + min);
        }
    }
}
