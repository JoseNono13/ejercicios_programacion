﻿using System;

namespace Ejercicio_7_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 7. Calcular las dos soluciones de una ecuación de segundo grado, del tipo ax2 + bx + c = 0. 
            //    Los coeficientes a, b y c deberá introducirlos el usuario a través del teclado.

            double a, b, c, raizCuadrada, x1, x2, resultado;

            Console.WriteLine("ax2 + bx + c = 0");
            Console.WriteLine("Dime a:");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime b:");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime c:");
            c = int.Parse(Console.ReadLine());

            resultado = (b * b) - (4 * a * c);

            if (0 <= resultado)
            {
                raizCuadrada = Math.Sqrt(resultado);

                x1 = (-b + raizCuadrada) / (2 * a);
                x2 = (-b - raizCuadrada) / (2 * a);

                Console.WriteLine("Resultado x1 = " + x1);
                Console.WriteLine("Resultado x2 = " + x2);
            }
            else
            {
                Console.WriteLine("No tiene solución");
            }   
        }
    }
}
