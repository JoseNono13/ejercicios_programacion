﻿using System;

namespace Ejercicio_5_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 5. Leer tres números por teclado, A, B y C, y decidir si los números son consecutivos.

            int a, b, c;

            Console.WriteLine("Dime el número a:");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime el número b:");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("Dime el número c:");
            c = int.Parse(Console.ReadLine());

            if (a == b - 1 && b == c - 1)
            {
                Console.WriteLine("Están ordenados");
            }
            else
            {
                Console.WriteLine("Ëstán desordenados");
            }
        }
    }
}
