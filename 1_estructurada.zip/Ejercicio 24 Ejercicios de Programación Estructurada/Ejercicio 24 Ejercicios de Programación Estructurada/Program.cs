﻿using System;

namespace Ejercicio_24_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 24. Escribe un programa que nos escriba los números impares comprendidos entre 1 y 10.

            for (int i = 1; i <= 10; i++)
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
    }
}
