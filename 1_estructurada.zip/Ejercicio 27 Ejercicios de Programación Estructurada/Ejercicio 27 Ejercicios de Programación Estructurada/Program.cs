﻿using System;

namespace Ejercicio_27_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 27. Escribe un programa que te escribe la tabla de multiplicar del número que le introduzcas 
            //     por teclado.

            int n, result;

            Console.WriteLine("Dime un número");
            n = int.Parse(Console.ReadLine());

            Console.WriteLine("TABLA DE MULTIPLICAR DEL " + n);

            for (int i = 0; i <= 10; i++)
            {
                result = n * i;
                Console.WriteLine(n + " x " + i + " = " + result);
            }
        }
    }
}
