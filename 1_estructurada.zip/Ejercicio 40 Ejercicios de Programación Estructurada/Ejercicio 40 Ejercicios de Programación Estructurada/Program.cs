﻿using System;

namespace Ejercicio_40_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 40.Escribe un programa que nos diga si un número es primo o no.

            int n;
            bool primo = true;
            int i = 2;

            Console.Write("Dime un número: ");
            n = int.Parse(Console.ReadLine());

            if (n == 1)
            {
                Console.WriteLine("True");
            }
            else
            {
                while ((primo) && (i != n))
                {
                    if (n % i == 0)
                    {
                        primo = false;
                    }

                    i++;
                }

                Console.WriteLine(primo);
            } 
        }
    }
}
