﻿using System;

namespace Ejercicio_12_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 12. Escribe un programa que te pregunte si quieres números pares o impares. Si te dice 
            //     pares, escribe los números pares del 1 al 10 y si te dice impares, escribe los números
            //     impares del 1 al 10.

            int opcion, n = 1;

            Console.WriteLine("Pulsa 1 si quieres los 10 primeros números pares");
            Console.WriteLine("Pulsa 2 si quieres los 10 primeros números imapres");
            opcion = int.Parse(Console.ReadLine());
            Console.WriteLine("");

            if (opcion == 1)
            {
                while (n <= 10)
                {
                    if (n % 2 == 0)
                    {
                        Console.WriteLine(n);
                    }

                    n++;
                }    
            }
            else 
            {
                if (opcion == 2)
                {
                    while (n <= 10)
                    {
                        if (n % 2 != 0)
                        {
                            Console.WriteLine(n);
                        }

                        n++;
                    }
                }
                else
                {
                    Console.WriteLine("Opción no válida");
                }
            }

        }
    }
}
