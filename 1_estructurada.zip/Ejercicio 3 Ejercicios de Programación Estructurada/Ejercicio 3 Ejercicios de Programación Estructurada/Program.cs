﻿using System;

namespace Ejercicio_3_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 3. Leer un número real y un tipo de moneda, que puede ser "euro" o "peseta".Convertir
            //    la cantidad al tipo de moneda indicado, suponiendo que está expresada en la otra.Por
            //    ejemplo, si la cantidad es 15 y la moneda es "peseta", se supondrá que se trata de 15 € 
            //    y que hay que convertirlos a pesetas y, por lo tanto, el resultado debe ser 2495.

            int opcion;
            double cantidad, resultado;

            Console.WriteLine("Si lo quieres pasar pesetas a euros pulsa 0");
            Console.WriteLine("Si lo quieres pasar euros a pesetas pulsa 1");
            opcion = int.Parse(Console.ReadLine());

            Console.WriteLine("Dime la cantidad");
            cantidad = double.Parse(Console.ReadLine());

            if (opcion == 0)
            {
                resultado = cantidad * 166.386;

                Console.WriteLine("Los " + cantidad + " euros en pesetas son " + resultado);
            }
            else 
            {
                if (opcion == 1)
                {
                    resultado = cantidad / 166.386;

                    Console.WriteLine("Las " + cantidad + " pesetas en euros son " + resultado);
                }
            }

        }
    }
}
