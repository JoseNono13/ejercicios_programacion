﻿using System;

namespace Ejercicio_11_Ejercicios_de_Programación_Estructurada
{
    class Program
    {
        static void Main(string[] args)
        {
            // 11. Escribe un programa que nos escriba los 10 primeros números pares.

            int n = 2;

            while (n <= 20)
            {
                if (n % 2 == 0)
                {
                    Console.WriteLine(n);
                }

                n++;
            }
        }
    }
}
