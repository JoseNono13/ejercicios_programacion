﻿using System;

namespace funciones5
{
    class Program
    {
        // 5. Escribe una función “Signo” a la que le pasemos un número y nos devuelva “1” si es 
        //    positivo, “0” si es cero y “-1” si es negativo.
        static int Signo(int n)
        {
            int resultado;

            if (n > 0)
            {
                resultado = 1;
            }
            else
            {
                if (n == 0)
                {
                    resultado = 0;
                }
                else
                {
                    resultado = -1;
                }
            }

            return resultado;
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("El resultado de la función signo es: " + Signo(n));
        }
    }
}
