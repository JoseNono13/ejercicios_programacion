﻿using System;

namespace funciones3
{
    class Program
    {
        // 3. Escribe una función “TablaMultiplicar” a la que le pases un entero y nos escriba la 
        //    tabla de multiplicar de ese número.
        static void TablaMultiplicar()
        {
            int n, resultado;
            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                resultado = n * i;

                Console.WriteLine(n + " x " + i + " = " + resultado);
            }
        }

        static void Main(string[] args)
        {
            TablaMultiplicar();
        }
    }
}
