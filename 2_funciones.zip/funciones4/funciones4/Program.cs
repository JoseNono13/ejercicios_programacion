﻿using System;

namespace funciones4
{
    class Program
    {
        // 4. Escribe una función “ImprimeSerie” a la que le pases dos enteros y te escriba por la 
        //    pantalla todos los valores comprendidos entre ambos.Lo hará en orden ascendente si
        //    el primero es menor que el segundo y descendente en caso contrario. Usa “for”.
        static void ImprimeSerie()
        {
            int n1, n2;
            Console.Write("Dime un número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.Write("Dime otro número: ");
            n2 = int.Parse(Console.ReadLine());

            if (n1 < n2)
            {
                for (int i = n1; i <= n2; i++)
                {
                    Console.WriteLine(i);
                }
            }
            else
            {
                if (n2 < n1)
                {
                    for (int i = n1; i >= n2; i--)
                    {
                        Console.WriteLine(i);
                    }
                }
                else
                {
                    Console.WriteLine("Los números son iguales");
                }
            }
        }
        static void Main(string[] args)
        {
            ImprimeSerie();
        }
    }
}
