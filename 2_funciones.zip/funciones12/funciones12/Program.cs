﻿using System;

namespace funciones12
{
    class Program
    {
        // 12. Escribe una función “PulgadasACentimetros” a la que le pases un valor en pulgadas (de 
        //     tipo double) y te devuelva el valor en centímetros.Haz también la función 
        //     “CentimetrosAPulgadas”.
        static double PulgadasACentimetros(double pulgadas)
        {
            double centimetros = pulgadas * 2.54;
            return centimetros;
        }

        static double CentimetrosAPulgadas(double centimetros)
        {
            double pulgadas = centimetros / 2.54;
            return pulgadas;
        }
        static void Main(string[] args)
        {
            Console.Write("Dime las pulgadas: ");
            double pulgadas = double.Parse(Console.ReadLine());
            Console.WriteLine(pulgadas + " pulgadas son " + PulgadasACentimetros(pulgadas) + " centimetros");
            Console.WriteLine("~~~~~~~~~~");
            Console.Write("Dime los centímetros: ");
            double centimetros = double.Parse(Console.ReadLine());
            Console.WriteLine(centimetros + " centimetros son " + CentimetrosAPulgadas(centimetros) + " pulgadas");
        }
    }
}
