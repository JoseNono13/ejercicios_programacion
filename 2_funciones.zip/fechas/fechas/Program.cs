﻿using System;

namespace fechas
{
    class Program
    {
        // 21. Escribe una función “DiasMes”, a la que le pasamos un mes(en formato numérico
        //     1 = Enero, 2 = Febrero, etc.)y nos dice el número de días que tiene ese mes.
        static int DiasMes(int mes)
        {
            int dias;
            switch (mes)
            {
                case 1: dias = 31; break;
                case 2: dias = 28; break;
                case 3: dias = 31; break;
                case 4: dias = 30; break;
                case 5: dias = 31; break;
                case 6: dias = 30; break;
                case 7: dias = 31; break;
                case 8: dias = 31; break;
                case 9: dias = 30; break;
                case 10: dias = 31; break;
                case 11: dias = 30; break;
                case 12: dias = 31; break;
                default: dias = 0; break;
            }

            return dias;
        }

        // 22. Debido a que en los años bisiestos el mes de Febrero tiene 29 días en lugar de 28,
        //     necesitaremos también dar el año para conseguir el resultado correcto.Escribe la
        //     función “DiasMes2” a la que le pasas un mes y un año(ambos enteros) y te dice
        //     cuántos días tiene ese mes, teniendo en cuenta si el año es bisiesto o no(NOTA: 
        //     Podéis usar la función “Bisiesto” que hicimos con anterioridad).
        static bool Bisiesto(int anno)
        {

            if ((anno % 4 == 0) && ((anno % 100 != 0) || (anno % 400 == 0)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static int DiasMes2(int mes, int anno)
        {
            int dias;

            if (mes == 2 && Bisiesto(anno))
            {
                dias = 29;
            }
            else
            {
                dias = DiasMes(mes);
            }
            return dias;
        }

        // 23. Escribe una función “DiasTranscurridos” a la que le pasamos tres enteros, el día, el 
        //     mes y el año, y nos dice cuántos días han pasado desde el inicio del año hasta ese día.
        //     Así, el 1 de enero será el día 1 y el 31 de diciembre será el 365 ó 366 dependiendo de
        //     si el año es bisiesto o no.
        static int DiasTranscurridos(int dia, int mes, int anno)
        {
            int diasTotales = 0;

            for (int i = 1; i < mes; i++)
            {
                diasTotales = diasTotales + DiasMes2(i, anno);
            }

            diasTotales = diasTotales + dia;

            return diasTotales;
        }

        // 24. Escribe una función “DiasTranscurridos1980” a la que le pasamos un día, mes y año y
        //     nos diga cuántos días han transcurrido desde el 01/01/1980 hasta ese día.
        static int DiasTranscurridos1980(int dia, int mes, int anno)
        {
            int diasTotales = 0;

            for (int i = 1980; i < anno; i++)
            {
                if (Bisiesto(i))
                {
                    diasTotales = diasTotales + 366;
                }
                else
                {
                    diasTotales = diasTotales + 365;
                }
            }

            diasTotales = diasTotales + DiasTranscurridos(dia, mes, anno);

            return diasTotales;
        }

        // 25. Escribe una función “DiasEntreFechas” a la que le pasamos 6 enteros. Un día, mes y 
        //     año y otro día, mes y año, y nos dice cuántos días han pasado entre ambas fechas.
        static int DiasEntreFechas(int dia1, int mes1, int anno1, int dia2, int mes2, int anno2)
        {
            return DiasTranscurridos1980(dia2, mes2, anno2) - DiasTranscurridos1980(dia1, mes1, anno1);
        }

        // 26. Teniendo en cuenta que el 01/01/1980 era martes, haz una función 
        //     “DiaSemanaFecha” que nos devuelva qué día de la semana corresponde a la fecha
        //     (día, mes y año) que le pasamos en 3 parámetros.Nos devolverá un entero que
        //     corresponderá al día de la semana(1=lunes, 2=martes, etc.).
        public static int DiaSemanaFecha(int dia, int mes, int anno)
        {
            int diasTotales = DiasTranscurridos1980(dia, mes, anno);
            int resto = diasTotales % 7;
            int diaSemana = resto + 1;
            return diaSemana;
        }
        static void Main(string[] args)
        {
            int option;

            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("Relación de Ejercicios de Funciones (3) Parte 1 – Ejercicios con fechas");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("1- DiasMes                 4- DiasTranscurridos1980");
            Console.WriteLine("2- DiasMes2                5- DiasEntreFechas");
            Console.WriteLine("3- DiasTranscurridos       6- DiaSemanaFecha");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine();
            Console.Write("Elige un ejercicio: ");
            option = int.Parse(Console.ReadLine());
            Console.WriteLine();

            switch (option)
            {
                case 1:
                    {
                        Console.WriteLine("----------------------");
                        Console.WriteLine("1- DiasMes");
                        Console.WriteLine("----------------------");
                        int mes;
                        Console.Write("Dime un mes: ");
                        mes = int.Parse(Console.ReadLine());
                        Console.WriteLine("El mes " + mes + " tiene " + DiasMes(mes) + " dias");
                        Console.WriteLine("----------------------");
                    }
                    break;

                case 2:
                    {
                        Console.WriteLine("------------------------------------");
                        Console.WriteLine("2- DiasMes2");
                        Console.WriteLine("------------------------------------");
                        int mes, anno;
                        Console.Write("Dime un mes: ");
                        mes = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno = int.Parse(Console.ReadLine());
                        Console.WriteLine("El mes " + mes + ", del año " + anno + " tiene " + DiasMes2(mes, anno) + " dias");
                        Console.WriteLine("------------------------------------");
                    }
                    break;

                case 3:
                    {
                        Console.WriteLine("-----------------------------------------------------------------");
                        Console.WriteLine("4- DiasTranscurridos");
                        Console.WriteLine("-----------------------------------------------------------------");
                        int dia, mes, anno;
                        Console.Write("Dime un dia: ");
                        dia = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes: ");
                        mes = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno = int.Parse(Console.ReadLine());
                        Console.WriteLine("Han pasado " + DiasTranscurridos(dia, mes, anno) + " dias desde el inicio del año hasta la fecha " + dia + "/" + mes + "/" + anno);
                        Console.WriteLine("-----------------------------------------------------------------");
                    }
                    break;
                case 4:
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("4- DiasTranscurridos1980");
                        Console.WriteLine("---------------------------------------------------");
                        int dia, mes, anno;
                        Console.Write("Dime un dia: ");
                        dia = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes: ");
                        mes = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno = int.Parse(Console.ReadLine());
                        Console.WriteLine("Han pasado " + DiasTranscurridos1980(dia, mes, anno) + " dias desde la fecha 01/01/1980");
                        Console.WriteLine("---------------------------------------------------");
                    }
                    break;
                case 5:
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("5- DiasEntreFechas");
                        Console.WriteLine("---------------------------------------------------");
                        int dia1, mes1, anno1, dia2, mes2, anno2;
                        Console.WriteLine();
                        Console.WriteLine("~~~~~~~~~~~~~");
                        Console.WriteLine("Primera fecha");
                        Console.Write("Dime un dia: ");
                        dia1 = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes: ");
                        mes1 = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno1 = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        Console.WriteLine("~~~~~~~~~~~~~");
                        Console.WriteLine("Segunda fecha");
                        Console.Write("Dime un dia: ");
                        dia2 = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes: ");
                        mes2 = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno2 = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        Console.WriteLine("Han pasado " + DiasEntreFechas(dia1, mes1, anno1, dia2, mes2, anno2) + " dias entre " + dia1 + "/" + mes1 + "/" + anno1 + " y " + dia2 + "/" + mes2 + "/" + anno2);
                        Console.WriteLine("---------------------------------------------------");
                    }
                    break;
                case 6: 
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("6- DiaSemanaFecha");
                        Console.WriteLine("---------------------------------------------------");
                        int dia, mes, anno;
                        Console.Write("Dime un dia: ");
                        dia = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes: ");
                        mes = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        anno = int.Parse(Console.ReadLine());
                        Console.WriteLine(DiaSemanaFecha(dia, mes, anno));
                        Console.WriteLine("---------------------------------------------------");
                    }
                    break;
            }
        }
    }
}
