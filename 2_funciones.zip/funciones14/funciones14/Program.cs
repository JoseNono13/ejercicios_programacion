﻿using System;

namespace funciones14
{
    class Program
    {
        // 14. Escribe una función “LeeNatural” que nos lea un número natural desde el teclado. La 
        //     función nos pondrá un texto en el que se nos indica que introduzcamos un número y
        //     después nos leerá el número del teclado.Si el número introducido es 0 o negativo, nos
        //     volverá a pedir otro número.
        static int LeeNatural(int n)
        {
            Console.Write("Escribe un número natural: ");
            n = int.Parse(Console.ReadLine());

            while (n <= 0)
            {
                Console.Write("El número no puede ser 0 o negativo, por favor introduce otro número: ");
                n = int.Parse(Console.ReadLine());
            }
            
            return n;
        }

        static void Main(string[] args)
        {
            LeeNatural(1);
        }
    }
}
