﻿using System;

namespace funciones1
{
    class Program
    {
        // 1. Escribe una función que te diga si un número es par o no. La función se llamará “Par” y 
        //    nos devolverá un valor booleano que será “verdadero” si el número es par y “falso” si
        //    es impar.
        static bool Par()
        {
            int n;

            Console.WriteLine("Dime un número:");
            n = int.Parse(Console.ReadLine());

            if (n % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Par());
        }
    }
}
