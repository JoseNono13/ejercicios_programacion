﻿using System;

namespace funciones15
{
    class Program
    {
        // 15. Escribe una función “LeeNumero” a la que le pasas dos parámetros (a y b) y nos lee del 
        //     teclado un número comprendido entre a y b(ambos incluidos). Si el número no es
        //     correcto, te vuelve a pedir que lo introduzcas.
        static int LeeNumero(int a, int b)
        {
            Console.Write("Escribe un número entre " + a + " y " + b + ": ");
            int n = int.Parse(Console.ReadLine());

            while (n < a || n > b)
            {
                Console.Write("Número no válido, debe estar entre " + a + " y " + b + ": ");
                n = int.Parse(Console.ReadLine());
            }
            return n;
        }
        static void Main(string[] args)
        {
            LeeNumero(0, 10);
        }
    }
}
