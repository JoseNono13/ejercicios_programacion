﻿using System;

namespace funciones10
{
    class Program
    {
        // 10. Escribe una función “Primo” que nos devuelva “verdadero” si el número que le 
        //     pasamos por parámetro es primo y “falso” en caso contrario.
        static bool Primo(int n)
        {
            int i, divisores;
            divisores = 0;

            for (i = 1; i <= n; i++)
            {
                if (n % i == 0)
                {
                    divisores++;
                }
            }
            if (divisores == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine(Primo(n));
        }
    }
}
