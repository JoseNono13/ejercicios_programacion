﻿using System;

namespace horas
{
    class Program
    {
        // 30. Escribe una función “HoraASegundos” a la que le pasas 3 parámetros enteros (hora, 
        //     minutos y segundos) y te devuelve el total de segundos.
        static int HoraASegundos(int horas, int min, int seg)
        {
            return horas * 3600 + min * 60 + seg;
        }

        // 31. Escribe una función “EscribeHoraBonita” a la que le pasas tres parámetros (hora, 
        //     minutos y segundos) y te escribe por pantalla la hora en formato “HH:MM:SS”.
        static void EscribeHoraBonita(int horas, int min, int seg)
        {
            if (horas < 10)
            {
                Console.Write("0" + horas + ":");
            }
            else
            {
                Console.Write(horas + ":");
            }
            if (min < 10)
            {
                Console.Write("0" + min + ":");
            }
            else
            {
                Console.Write(min + ":");
            }
            if (seg < 10)
            {
                Console.WriteLine("0" + seg);
            }
            else
            {
                Console.WriteLine(seg);
            }
        }

        // 32. Escribe una función “EscribeSegundosBonito” a la que le pasas un parámetro que 
        //     corresponde al número de segundos y te escribe por pantalla la hora en formato 
        //     “HH:MM:SS”.
        static void EscribeSegundosBonito(int seg)
        {
            int h, m, s, min;
            min = seg / 60;
            s = seg % 60;
            h = min / 60;
            m = min % 60;

            EscribeHoraBonita(h, m, s);
        }

        // 33. Escribe una función “SegundosTranscurridos” a la que le pasas 2 horas (en total, 6 
        //     parámetros: hora, minutos y segundos para cada una de las dos horas) y te dice
        //     cuántos segundos han transcurrido entre una y otra.
        static int SegundosTranscurridos(int horas1, int min1, int seg1, int horas2, int min2, int seg2)
        {
            int s1 = HoraASegundos(horas1, min1, seg1);
            int s2 = HoraASegundos(horas2, min2, seg2);
            return s2 - s1;
        }
        // 34. Escribe una función “SegundosTranscurridos1980” a la que le pasas 6 parámetros: día, 
        //     mes, año, hora, minutos y segundos y te dice cuántos segundos han transcurrido
        //     desde el 1 de enero de 1980.
        static int SegundosTranscurridos1980(int dia, int mes, int anno, int horas, int min, int seg)
        {
            int diasTotales = DiasTranscurridos1980(dia, mes, anno) - 1;
            int s = diasTotales * 86400 + HoraASegundos(horas, min, seg);
            return s;
        }

        static int DiasMes(int mes)
        {
            int dias;
            switch (mes)
            {
                case 1: dias = 31; break;
                case 2: dias = 28; break;
                case 3: dias = 31; break;
                case 4: dias = 30; break;
                case 5: dias = 31; break;
                case 6: dias = 30; break;
                case 7: dias = 31; break;
                case 8: dias = 31; break;
                case 9: dias = 30; break;
                case 10: dias = 31; break;
                case 11: dias = 30; break;
                case 12: dias = 31; break;
                default: dias = 0; break;
            }

            return dias;
        }
        static int DiasMes2(int mes, int anno)
        {
            int dias;

            if (mes == 2 && Bisiesto(anno))
            {
                dias = 29;
            }
            else
            {
                dias = DiasMes(mes);
            }
            return dias;
        }
        static bool Bisiesto(int anno)
        {

            if ((anno % 4 == 0) && ((anno % 100 != 0) || (anno % 400 == 0)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static int DiasTranscurridos(int dia, int mes, int anno)
        {
            int diasTotales = 0;

            for (int i = 1; i < mes; i++)
            {
                diasTotales = diasTotales + DiasMes2(i, anno);
            }

            diasTotales = diasTotales + dia;

            return diasTotales;
        }
        static int DiasTranscurridos1980(int dia, int mes, int anno)
        {
            int diasTotales = 0;

            for (int i = 1980; i < anno; i++)
            {
                if (Bisiesto(i))
                {
                    diasTotales = diasTotales + 366;
                }
                else
                {
                    diasTotales = diasTotales + 365;
                }
            }

            diasTotales = diasTotales + DiasTranscurridos(dia, mes, anno);

            return diasTotales;
        }
        
        
        

        static void Main(string[] args)
        {
            int option;

            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("Relación de Ejercicios de Funciones (3) Parte 1 – Ejercicios con fechas");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine("1- HoraASegundos                 4- SegundosTranscurridos");
            Console.WriteLine("2- EscribeHoraBonita             5- SegundosTranscurridos1980");
            Console.WriteLine("3- EscribeSegundosBonito");
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine();
            Console.Write("Elige un ejercicio: ");
            option = int.Parse(Console.ReadLine());
            Console.WriteLine();

            switch (option)
            {
                case 1:
                    {
                        Console.WriteLine("----------------");
                        Console.WriteLine("1- HoraASegundos");
                        Console.WriteLine("----------------");
                        Console.Write("Dime la hora: ");
                        int horas = int.Parse(Console.ReadLine());
                        Console.Write("Dime los minutos: ");
                        int min = int.Parse(Console.ReadLine());
                        Console.Write("Dime los segundos: ");
                        int seg = int.Parse(Console.ReadLine());
                        HoraASegundos(horas, min, seg);
                        Console.WriteLine("----------------");
                    }
                    break;

                case 2:
                    {
                        Console.WriteLine("--------------------");
                        Console.WriteLine("2- EscribeHoraBonita");
                        Console.WriteLine("--------------------");
                        Console.Write("Dime la hora: ");
                        int horas = int.Parse(Console.ReadLine());
                        Console.Write("Dime los minutos: ");
                        int min = int.Parse(Console.ReadLine());
                        Console.Write("Dime los segundos: ");
                        int seg = int.Parse(Console.ReadLine());
                        EscribeHoraBonita(horas, min, seg);
                        Console.WriteLine("--------------------");
                    }
                    break;

                case 3:
                    {
                        Console.WriteLine("------------------------");
                        Console.WriteLine("3- EscribeSegundosBonito");
                        Console.WriteLine("------------------------");
                        Console.Write("Dime los segundos: ");
                        int seg = int.Parse(Console.ReadLine());
                        EscribeSegundosBonito(seg);
                        Console.WriteLine("------------------------");
                    }
                    break;

                case 4:
                    {
                        Console.WriteLine("------------------------");
                        Console.WriteLine("4- SegundosTranscurridos");
                        Console.WriteLine("------------------------");
                        Console.WriteLine("~~~~~~~~~~~~");
                        Console.WriteLine("Primera hora");
                        Console.WriteLine("~~~~~~~~~~~~");
                        Console.Write("Dime la hora: ");
                        int horas1 = int.Parse(Console.ReadLine());
                        Console.Write("Dime los minutos: ");
                        int min1 = int.Parse(Console.ReadLine());
                        Console.Write("Dime los segundos: ");
                        int seg1 = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        Console.WriteLine("~~~~~~~~~~~~");
                        Console.WriteLine("Segunda hora");
                        Console.WriteLine("~~~~~~~~~~~~");
                        Console.Write("Dime la hora: ");
                        int horas2 = int.Parse(Console.ReadLine());
                        Console.Write("Dime los minutos: ");
                        int min2 = int.Parse(Console.ReadLine());
                        Console.Write("Dime los segundos: ");
                        int seg2 = int.Parse(Console.ReadLine());
                        Console.WriteLine(SegundosTranscurridos(horas1, min1, seg1, horas2, min2, seg2));
                        Console.WriteLine("------------------------");
                    }
                    break;

                case 5:
                    {
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("5- SegundosTranscurridos1980");
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("~~~");
                        Console.WriteLine("DIA");
                        Console.WriteLine("~~~");
                        Console.Write("Dime un día: ");
                        int dia = int.Parse(Console.ReadLine());
                        Console.Write("Dime un mes en formato numérico 1=Enero, 2=Febrero, etc: ");
                        int mes = int.Parse(Console.ReadLine());
                        Console.Write("Dime un año: ");
                        int anno = int.Parse(Console.ReadLine());
                        Console.WriteLine();
                        Console.WriteLine("~~~~");
                        Console.WriteLine("HORA");
                        Console.WriteLine("~~~~");
                        Console.Write("Dime la hora: ");
                        int horas = int.Parse(Console.ReadLine());
                        Console.Write("Dime los minutos: ");
                        int min = int.Parse(Console.ReadLine());
                        Console.Write("Dime los segundos: ");
                        int seg = int.Parse(Console.ReadLine());
                        Console.WriteLine(SegundosTranscurridos1980(dia, mes, anno, horas, min, seg));
                        Console.WriteLine("------------------------");
                    }
                    break;
            }
        }
    }
}
