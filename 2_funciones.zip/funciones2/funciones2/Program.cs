﻿using System;

namespace funciones2
{
    class Program
    {
        // 2. Escribe una función que nos diga si un año es bisiesto o no. La función se llamará 
        //    “Bisiesto” y nos devolverá “verdadero” si es bisiesto y “falso” si no lo es.
        static bool Bisiesto()
        {
            int anno;

            Console.WriteLine("Dime un año:");
            anno = int.Parse(Console.ReadLine());

            if ((anno % 4 == 0) && ((anno % 100 != 0) || (anno % 400 == 0)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Bisiesto());
        }
    }
}
