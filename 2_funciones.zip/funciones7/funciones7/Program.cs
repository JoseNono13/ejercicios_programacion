﻿using System;

namespace funciones7
{
    class Program
    {
        // 7. Escribe una función “Min” que nos devuelva el menor de los dos números que le 
        //    pasemos por parámetro.
        static int Min(int n1, int n2)
        {
            if (n1 < n2)
            {
                return n1;
            }
            else
            {
                return n2;
            }
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n1 = int.Parse(Console.ReadLine());

            Console.Write("Dime otro número: ");
            int n2 = int.Parse(Console.ReadLine());

            Console.WriteLine("El número menor es: " + Min(n1, n2));
        }
    }
}
