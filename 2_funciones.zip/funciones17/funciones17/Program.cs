﻿using System;

namespace funciones17
{
    class Program
    {
        // 17. Escribe una función “Factorial” que nos calcule el factorial de un número entero.
        static int Factorial(int n)
        {
            int i;
            int fact = 1;

            for (i = 1; i <= n; i++)
            {
                fact *= i;
            }
            return fact;
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine("El factorial de " + n + "! es " + Factorial(n));
        }
    }
}
