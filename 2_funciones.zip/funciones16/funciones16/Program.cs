﻿using System;

namespace funciones16
{
    class Program
    {
        // 16. Escribe una función “Elevado” a la que le pasas dos números enteros (a y b) y te 
        //     devuelve el valor de “a” elevado a “b” (sin usar la función Math.Pow) (o sea,
        //     multiplicando un número muchas veces).
        static int Elevado(int a, int b)
        {
            int i;
            int potencia = 1;

            for (i = 1; i <= b; i++)
            {
                potencia = potencia * a;
            }
            return potencia;
        }

        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Dime a que número quieres elevar " + a + ": ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine(a + " elevado a " + b + " es " + Elevado(a, b));
        }
    }
}
