﻿using System;

namespace funciones13
{
    class Program
    {
        // 13. Escribe una función “NotaEnTexto” a la que le pasamos la nota de un alumno como un 
        //     double y nos devolverá la calificación en formato texto(“aprobado”, “suficiente”, etc.)
        static void NotaEnTexto(double nota)
        {

            if (nota < 0 || nota > 10)
            {
                Console.WriteLine("Nota no válida");
            }
            else
            {
                if (nota < 5)
                {
                    Console.WriteLine("Insuficiente");
                }
                else
                {
                    if (nota < 6)
                    {
                        Console.WriteLine("Suficiente");
                    }
                    else
                    {
                        if (nota < 7)
                        {
                            Console.WriteLine("Bien");
                        }
                        else
                        {
                            if (nota < 9)
                            {
                                Console.WriteLine("Notable");
                            }
                            else
                            {
                                Console.WriteLine("Sobresaliente");
                            }
                        }
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            Console.Write("Dime la nota del alumno: ");
            double nota = double.Parse(Console.ReadLine());
            NotaEnTexto(nota);
        }
    }
}
