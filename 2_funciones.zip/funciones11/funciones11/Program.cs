﻿using System;

namespace funciones11
{
    class Program
    {
        // 11. Escribe una función “AreaTriangulo” que te calcule el área de un triángulo. Habrá que 
        //     pasarle como parámetros la base y la altura.
        static double AreaTriangulo(double b, double h)
        {
            double a;

            a = (b * h) / 2.0;

            return a;
        }


        static void Main(string[] args)
        {
            Console.Write("Dime la base del triángulo: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("Dime la altura del triángulo: ");
            int h = int.Parse(Console.ReadLine());
            Console.WriteLine(AreaTriangulo(b, h));
        }
    }
}
