﻿using System;

namespace funciones6
{
    class Program
    {
        // 6. Escribe una función “Max” que nos devuelva el mayor de los dos números que le 
        //    pasemos por parámetro.
        static int Max(int n1, int n2)
        {
            if (n1 > n2)
            {
                return n1;
            }
            else
            {
                return n2;
            }
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n1 = int.Parse(Console.ReadLine());

            Console.Write("Dime otro número: ");
            int n2 = int.Parse(Console.ReadLine());

            Console.WriteLine("El número mayor es: " + Max(n1, n2));
        }
    }
}
