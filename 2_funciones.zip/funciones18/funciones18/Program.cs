﻿using System;

namespace funciones18
{
    class Program
    {
        // 18. Escribe una función “ResolucionCamara” a la que le pasas el número de MegaPixels 
        //     que tiene una cámara digital(puede ser un double) y nos dice cuál es la resolución
        //     máxima de las fotos que hace la cámara. Los valores los devolverá en dos parámetros
        //     de tipo out (x, y).
        static void ResolucionCamara(double megaPixeles)
        {
            double pixeles = megaPixeles * 1000000;
            double x, y;
            double relacionAspecto = 16.0 / 9.0;
            int xInt, yInt;

            y = Math.Sqrt(pixeles / relacionAspecto);
            x = pixeles / y;

            xInt = (int)Math.Floor(x);
            yInt = (int)Math.Floor(y);
            Console.WriteLine("La imagen sería de " + x + " x " + y);
        }
        static void Main(string[] args)
        {
            ResolucionCamara(2.0736);
        }
    }
}
