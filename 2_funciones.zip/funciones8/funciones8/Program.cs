﻿using System;

namespace funciones8
{
    class Program
    {
        // 8. Escribe una función que nos calcule el “MCD” de dos números.
        static int MCD(int n1, int n2)
        {
            int temp;
            while (n2 != 0)
            {
                temp = n2;
                n2 = n1 % n2;
                n1 = temp;
            }
            return n1;
        }
        static void Main(string[] args)
        {
            Console.Write("Dime un número: ");
            int n1 = int.Parse(Console.ReadLine());

            Console.Write("Dime otro número: ");
            int n2 = int.Parse(Console.ReadLine());

            Console.WriteLine("El MCD es: " + MCD(n1, n2));
        }
    }
}
