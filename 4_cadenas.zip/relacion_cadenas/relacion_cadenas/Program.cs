﻿using System;

namespace relacion_cadenas
{
    class Program
    {
        // 1. Escribe la función “NumeroEspacios” a la que le pasamos una cadena y nos devuelve el
        //    número de espacios que contiene esa cadena (tanto al principio y al final como intercalados).
        static int NumeroEspacios(string s)
        {
            int espacios = 0;

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ' ')
                {
                    espacios++;
                }
            }

            return espacios;
        }

        // 2. Escribe la función “NumeroVocales” a la que le pasamos una cadena y nos devuelve el 
        //    número de vocales que hay en la cadena.
        static int NumeroVocales(string s) 
        {
            int vocales = 0;
            string vocal = "aeiouáéíóúüAEIOUÁÉÍÓÚÜ";

            for (int i = 0; i < s.Length; i++)
            {
                if (vocal.Contains(s[i]))
                {
                    vocales++;
                }
            }

            return vocales;
        }

        // 3. Escribe la función “EsPalindromo” a la que le pasamos una cadena y nos dice si la 
        //    cadena es un palíndromo(true) o no(false). Un palíndromo es una palabra o frase que
        //    se lee igual al revés que al derecho.
        static bool EsPalindromo(string s) 
        {
            int j = s.Length - 1;

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] != s[j])
                {
                    return false;
                }
                j--;
            }

            return true;
        }

        // 4. Escribe la función “Contiene” a la que le pasamos una cadena y un carácter por 
        //    parámetro y nos dice si el carácter aparece en la cadena o no.Es igual que la función
        //    Contains.Evidentemente, no podéis usar esta función para hacer la vuestra.
        static bool Contiene(string s, char c) 
        {
            bool contiene = false;   
            
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == c)
                {
                    contiene = true;
                }
            }

            return contiene;
        }

        // 5. Escribe la función “RepiteCaracter” a la que le pasamos dos parámetros: un carácter y 
        //    un entero.La función nos devolverá una cadena que contendrá el carácter repetido
        //    tantas veces como indique el entero. Ej.: RepiteCaracter(‘A’, 5) = “AAAAA”. No se
        //    pueden utilizar PadLeft ni PadRight.
        static string RepiteCaracter(char c, int n)
        {
            string s = "";

            for (int i = 0; i < n; i++)
            {
                s = s + c;
            }

            return s;
        }

        // 6. Escribe la función “QuitaEspacios” a la que le pasamos una cadena y nos devuelve la 
        //    misma cadena, pero con todos los espacios quitados(tanto los del principio como los
        //    del final como los intermedios).
        static string QuitaEspacios(string s) 
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ' ')
                {
                    s = s.Remove(i, 1);
                    i--;
                }
            }

            return s;
        }

        // 7. Escribe la función “QuitaEspaciosTrim” a la que le pasamos una cadena y nos devuelve 
        //    otra cadena igual que la primera en la que se han eliminado los espacios que haya al
        //    principio y al final.No se puede utilizar Trim (ni sus variantes).
        static string QuitaEspaciosTrim(string s)
        {
            string s2 = s;
            for (int i = 0; i < s2.Length; i++)
            {
                if (s2[i] != ' ')
                {
                    i = s2.Length;
                }
                else
                {
                    s2 = s2.Remove(i, 1);
                    i--;
                }
            }

            for (int j = s2.Length - 1; j >= 0; j--)
            {
                if (s2[j] != ' ')
                {
                    j = 0;
                }
                else
                {
                    s2 = s2.Remove(j, 1);
                }
            }

            return s2;
        }

        // 8. Escribe la función “SustituyeCaracter” a la que le pasamos una cadena, un carácter y 
        //    otro carácter y nos devuelve otra cadena igual que la primera en la que se ha
        //    sustituido el primer carácter por el segundo carácter. Ojo, en las cadenas, al contrario
        //    que en los arrays, no podemos modificar directamente un valor al estilo de cadena[2]
        //    = ‘A’ (los corchetes sólo sirven para leer el valor, no para modificarlo).
        static string SustituyeCaracter(string s, char c1, char c2) 
        {
            string s2 = s;

            for (int i = 0; i < s2.Length; i++)
            {
                if (s2[i] == c1)
                {
                    s2 = s2.Remove(i, 1);
                    s2 = s2.Insert(i, c2.ToString());
                }
            }

            return s2;
        }

        // 9. Escribe la función “CuentaPalabras” a la que le pasamos una cadena que contiene una 
        //    frase y nos devuelve el número de palabras que hay en la misma.
        static int CuentaPalabras(string s) 
        {
            int palabras = 0;
            s = " " + s;

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == ' ' && s[i + 1] != ' ')
                {
                    palabras++;
                }
            }

            return palabras;
            //return s.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
        }

        // 10. Escribe la función “EsNumero”, a la que le pasamos una cadena y nos dice si está 
        //     formada enteramente por números o no. Esta función es muy interesante para
        //     evitarnos errores a la hora de hacer un Console.ReadLine.Si queremos leer un número
        //     del teclado, lo correcto es leerlo con un Console.ReadLine como si fuera una cadena,
        //     después comprobar con la función EsNumero si está formado completamente por
        //     dígitos y después hacerle un int.Parse para pasarlo a un entero. Así no peta tanto.
        static bool EsNumero(string s) 
        {
            int cont = 0;

            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsDigit(s[i]))
                {
                    cont++;
                }
            }

            if (cont == s.Length)
            {
                return true;
            }
            else 
            {
                return false;
            }
        }

        // 11. Escribe la función “QuitaCaracter” a la que le pasamos una cadena y un carácter y nos 
        //     devuelve la cadena, pero con todas las ocurrencias de ese carácter quitadas.
        static string QuitaCaracter(string s, char c) 
        {
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == c)
                {
                    s = s.Remove(i, 1);
                }
            }

            return s;
        }

        // 12. Escribe la función “QuitaAcentos” a la que le pasas una cadena con caracteres 
        //     acentuados y te devuelve la cadena con los acentos quitados(esto se hace para algunos
        //     programas que no se enteran de los acentos).
        static string QuitaAcentos(string s) 
        {
            string con = "áéíóúüÁÉÍÓÚÜ";
            string sin = "aeiouuAEIOUU";
            int pos;

            for (int i = 0; i < s.Length; i++)
            {
                if (con.Contains(s[i]))
                {
                    pos = con.IndexOf(s[i]);
                    s = s.Remove(i, 1);
                    s = s.Insert(i, sin[pos].ToString());
                }
            }

            return s;
        }

        // 13. Escribe la función “InvierteCadena” a la que le pasamos una cadena y nos la devuelve 
        //     invertida (de detrás para delante, vamos).
        static string InvierteCadena(string s) 
        {
            string temp = "";
            int j = s.Length;

            for (int i = s.Length - 1; i >= 0; i--)
            {
                temp = temp + s[i];
            }

            string s2 = temp;

            return s2;
        }

        // 14. Escribe la función “VecesCaracter” a la que le pasamos una cadena y un carácter y nos 
        //     dice cuántas veces se repite ese carácter.
        static int VecesCaracter(string s, char c) 
        {
            int n = 0;

            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == c)
                {
                    n++;
                }
            }

            return n; 
        }

        // 15. Escribe la función “VecesPalabra” a la que le pasamos una cadena y una palabra (otra 
        //     cadena) y nos dice cuántas veces se repite ese palabra en la cadena.
        static int VecesPalabra(string s, string palabra) 
        {
            int n = 0;
            string[] subs = s.Split(' ');

            for (int i = 0; i < subs.Length; i++)  
            {
                if (subs[i] == palabra)
                {
                    n++;
                }
            }

            return n;
        }

        // 16. Escribe la función “MayusculasPrimera” a la que le pasas una cadena y te devuelve la 
        //     cadena con la primera letra de cada palabra puesta en mayúsculas.
        static string MayusculasPrimera(string s) 
        {
            s = " " + s;

            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] != ' ' && s[i - 1] == ' ') 
                { 
                    char letra = char.ToUpper(s[i]);
                    s = s.Remove(i, 1);
                    s = s.Insert(i, letra.ToString());
                }
            }

            string s2 = s.Remove(0, 1);
            
            return s2;
        }

        static string MayusculasPrimera2(string s) 
        {
            string[] subs = s.Split(' ');

            for (int i = 0; i < subs.Length; i++)
            {
                string palabra = subs[i];
                palabra = char.ToUpper(palabra[0]) + palabra.Remove(0, 1);
                subs[i] = palabra;

            }

            string s2 = string.Join(' ', subs);

            return s2;
        }

        // 17. Escribe la función “SustituyePalabra” a la que le pasamos una cadena y dos palabras y 
        //     nos devuelve otra cadena en la que haya que sustituir la primera por la segunda.
        static string SustituyePalabra(string s, string palabra1, string palabra2) 
        {
            string[] subs = s.Split(' ');

            for (int i = 0; i < subs.Length; i++)
            {
                if (subs[i] == palabra1)
                {
                    subs[i] = palabra2;
                }
            }

            string s2 = string.Join(' ', subs);

            return s2;
        }

        // 18. Escribe una función “InviertePalabras” a la que la pasamos una cadena y nos devuelve 
        // otra en la que están invertidas todas las palabras(no la cadena entera, sino cada palabra independientemente).
        static string InviertePalabras(string s) 
        {
            string[] subs = s.Split(' ');

            for (int i = 0; i < subs.Length; i++)
            {
                subs[i] = InvierteCadena(subs[i]);
            }

            string s2 = string.Join(' ', subs);

            return s2;
        }

        // 19. Escribe una función “MarcaSubCadena” a la que le pasamos dos cadenas y nos busca la 
        //     segunda cadena dentro de la primera.Nos devolverá otra cadena igual que la primera,
        //     pero en la que se cambiará la primera letra de cada vez que aparece la subcadena por un asterisco.
        //     "hola don pepito hola don josé"
        //     "la"
        //     "ho*a don pepito ho*a don josé"
        static string MarcaSubCadena(string s1, string s2)
        {
            

            for (int i = 0; i < s1.Length - s2.Length; i++)
            {
                if (s1.Substring(i, s2.Length) == s2)
                {
                    s1 = s1.Remove(i, 1);
                    s1 = s1.Insert(i, "*");
                }
            }

            return s1;
        }

        // 20. Escribe la función “QuitaEspaciosSobrantes” a la que le pasamos una cadena por 
        //     parámetro y nos devuelve otra. La cadena que le pasamos podrá tener espacios
        //     delante y detrás, además de espacios entre las palabras.Para obtener la cadena
        //     resultado, tendremos que quitar los espacios de delante y de detrás y si entre dos
        //     palabras hay más de un espacio, deberemos dejar sólo uno. 
        //     Ej.: “~~~Mi~~mamá~~~~me~mima~~” -> “Mi ~mamá~me~mima” (~ = espacio)
        static string QuitaEspaciosSobrantes(string s) 
        {
            s = QuitaEspaciosTrim(s);

            for (int i = 0; i < s.Length - 1; i++)
            {
                if (s[i] == ' ' && s[i + 1] == ' ')
                {
                    s = s.Remove(i, 1);
                    i--;
                }
            }

            return s;
        }

        // 2. Escribe la función EscribeNombres a la que le pasamos una cadena por parámetro y 
        //    nos la escribe por la pantalla(con println) con el siguiente formato: la cadena
        //    contendrá varias palabras separadas por espacios, con el siguiente formato: 
        //    “apellido1 apellido2 nombre apellido1 apellido2 nombre(…)” y deberemos
        //    escribirla por pantalla de la siguiente forma: 
        //    nombre apellido1 apellido2
        //    nombre apellido1 apellido2
        //    (…)
        static void EscribeNombres(string s) 
        {
            int i;
            string[] subs = s.Split(' ');
            string s2 = "";

            for (i = 0; i < subs.Length - 2; i=i+3)
            {
                s2 = subs[i + 2] + " " + subs[i] + " " + subs[i + 1];
                Console.WriteLine(s2);
            }
        }



        static void Main(string[] args)
        {
            Console.WriteLine("┌────────────────────────┬────────────────────────┐");
            Console.WriteLine("│ Relación de Ejercicios │ Relación de Ejercicios │");
            Console.WriteLine("│ de Cadenas (1)         │ de Cadenas (2)         │");
            Console.WriteLine("├────────────────────────┼────────────────────────┤");
            Console.WriteLine("│ 1. NumeroEspacios      │ 11. QuitaCaracter      │");
            Console.WriteLine("│ 2. NumeroVocales       │ 12. QuitaAcentos       │");
            Console.WriteLine("│ 3. EsPalindromo        │ 13. InvierteCadena     │");
            Console.WriteLine("│ 4. Contiene            │ 14. VecesCaracter      │");
            Console.WriteLine("│ 5. RepiteCaracter      │ 15. VecesPalabra       │");
            Console.WriteLine("│ 6. QuitaEspacios       │ 16. MayusculasPrimera  │");
            Console.WriteLine("│ 7. QuitaEspaciosTrim   │ 17.                    │");
            Console.WriteLine("│ 8. SustituyeCaracter   │ 18.                    │");
            Console.WriteLine("│ 9. CuentaPalabras      │ 19.                    │");
            Console.WriteLine("│10. EsNumero            │ 20.                    │");
            Console.WriteLine("└────────────────────────┴────────────────────────┘");
            Console.Write("Dime un ejercicio: ");
            int option = int.Parse(Console.ReadLine());

            switch (option)
            {
                case 1:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        int n = NumeroEspacios(s);
                        Console.WriteLine(n);
                    }
                    break;
                case 2:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        int n = NumeroVocales(s);
                        Console.WriteLine(n);
                    }
                    break;
                case 3:
                    {
                        string s = "oro";
                        Console.WriteLine(s);
                        Console.WriteLine(EsPalindromo(s));
                    }
                    break;
                case 4:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        char c = 'a';
                        Console.WriteLine(Contiene(s, c));
                    }
                    break;
                case 5:
                    {
                        Console.WriteLine(RepiteCaracter('A', 5));
                    }
                    break;
                case 6:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        Console.WriteLine(QuitaEspacios(s));
                    }
                    break;
                case 7:
                    {
                        string s = "   hola don pepito     ";
                        Console.WriteLine(s);
                        Console.WriteLine(">" + QuitaEspaciosTrim(s) + "<");
                    }
                    break;
                case 8:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        Console.WriteLine(SustituyeCaracter(s, 'h', 'H'));
                    }
                    break;
                case 9:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        int n = CuentaPalabras(s);
                        Console.WriteLine(n);
                    }
                    break;
                case 10:
                    {
                        string s = "12345";
                        Console.WriteLine(s);
                        Console.WriteLine(EsNumero(s));
                        string s2 = "a2345";
                        Console.WriteLine(s2);
                        Console.WriteLine(EsNumero(s2));
                    }
                    break;
                case 11: 
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        Console.WriteLine(QuitaCaracter(s, 'o'));
                    }
                    break;
                case 12:
                    {
                        string s = "hólá dón pépíto";
                        Console.WriteLine(s);
                        Console.WriteLine(QuitaAcentos(s));
                    }
                    break;
                case 13:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        Console.WriteLine(InvierteCadena(s));
                    }
                    break;
                case 14:
                    {
                        string s = "hola don pepito";
                        Console.WriteLine(s);
                        Console.WriteLine(VecesCaracter(s, 'o'));
                    }
                    break;
                case 15:
                    {
                        string s = "hola don pepito hola don josé";
                        Console.WriteLine(s);
                        Console.WriteLine(VecesPalabra(s, "hola"));
                    }
                    break;
                case 16:
                    {
                        string s = "hola don pepito hola don josé";
                        Console.WriteLine(s);
                        Console.WriteLine(MayusculasPrimera(s));
                        Console.WriteLine(MayusculasPrimera2(s));
                    }
                    break;
                case 17:
                    {
                        string s = "hola don pepito hola don josé";
                        Console.WriteLine(s);
                        Console.WriteLine(SustituyePalabra(s, "hola", "adiós"));
                    }
                    break;
                case 18:
                    {
                        string s = "hola don pepito hola don josé";
                        Console.WriteLine(s);
                        Console.WriteLine(InviertePalabras(s));
                    }
                    break;
                case 19:
                    {
                        string s1 = "hola don pepito hola don josé";
                        string s2 = "la";
                        Console.WriteLine(s1);
                        Console.WriteLine(s2);
                        Console.WriteLine(MarcaSubCadena(s1, s2));
                    }
                    break;
                case 20:
                    {
                        string s = "   Mi  mamá    me mima  ";
                        Console.WriteLine(s);
                        Console.WriteLine(">" + QuitaEspaciosSobrantes(s) + "<");
                    }
                    break;
                case 21: { }break;
                case 22: 
                    {
                        string s = "González Sánchez Nono Cuadrado Galardo Noelia";
                        Console.WriteLine(s);
                        EscribeNombres(s);
                    }
                    break;

            }
        }
    }
}